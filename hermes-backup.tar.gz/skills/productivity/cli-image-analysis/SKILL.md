---
name: cli-image-analysis
description: "Read/inspect raster images (JPG/PNG screenshots) from a terminal CLI that has NO native vision tool — use Pillow (metadata/EXIF) + tesseract (OCR) as the fallback."
version: 1.0.0
author: Hermes Agent
license: MIT
platforms: [linux, macos]
metadata:
  hermes:
    tags: [Image, OCR, Vision, Screenshot, Pillow, tesseract, Terminal]
    related_skills: [ocr-and-documents]
---

# CLI Image Analysis (no native vision)

The terminal CLI agent has **no pixel-vision / multimodal tool**. It cannot "see" an image the way a chat model with vision can. When the user says "read this image", "what does this screenshot say", or "analyze that picture", the working fallback is **metadata + OCR**, not description.

This skill covers **bare raster images** (JPG/PNG/phone screenshots). For PDFs or scanned documents, see `ocr-and-documents`.

## When to use
- User pastes a local file path, a `raw.githubusercontent.com/...` URL, or a public image link and asks what's in it / what it says.
- You need to confirm a downloaded file is really an image (not a 404 HTML page).

## Install (Debian-like / Codespaces)

```bash
# Pillow into the agent venv. PEP 668 managed envs require --break-system-packages:
pip install --break-system-packages pillow pytesseract

# The OCR engine is a system binary (needs sudo in most envs):
sudo apt-get update && sudo apt-get install -y tesseract-ocr
```

Check what's already present before installing:
```bash
python3 -c "import PIL; print('pillow ok')" 2>/dev/null || echo "pillow missing"
which tesseract || echo "tesseract missing"
```

## Run — metadata + OCR

```bash
IMG="/workspaces/_github_imgs/screenshot.jpg"

# 1) Sanity: is it really an image?
file "$IMG"

# 2) Metadata / EXIF (confirms type, dimensions, source device/software)
python3 - <<'PY'
from PIL import Image
from PIL.ExifTags import TAGS
img = Image.open("$IMG")
print("dims:", img.size, "| mode:", img.mode, "| format:", img.format)
for k, v in img.getexif().items():
    name = TAGS.get(k, k)
    if len(str(v)) < 200:
        print(f"  {name}: {v}")
PY

# 3) OCR — extract any printed text
tesseract "$IMG" stdout --psm 11 2>/dev/null | sed '/^$/d'
```

## tesseract page-segmentation modes
- `--psm 3` — default, automatic.
- `--psm 6` — assume a single uniform block of text.
- `--psm 11` — sparse text / no particular structure (good for screenshots with scattered UI text).

## Pitfalls & honesty
- **Small screenshots OCR poorly.** A 161x110 px phone capture yields partial, sometimes garbled text. Report exactly what's legible and state the rest may be truncated — don't invent content.
- **`file` says "ASCII text" after a raw download → you got a 404 page, not the image.** Resolve the repo's real default branch before building a `raw.githubusercontent.com` URL (default branch is often NOT `main`; see the GitHub no-auth read pattern). Verify with `file` before OCR.
- **OCR extracts TEXT only.** It cannot describe scenes, faces, colors, layout, or objects. Be explicit with the user about this limit; if they need scene understanding, say so plainly rather than guessing.
- **Upscaling rarely helps** tiny phone screenshots: `img.resize((w*3, h*3), Image.LANCZOS)` before OCR can marginally help but low-res captures stay unreadable.
- **PEP 668:** in managed venvs `pip install pillow` fails with "externally-managed-environment" — use `--break-system-packages` (or a dedicated venv).
- **No sudo?** `tesseract` binary won't install. Without it, fall back to metadata-only (Pillow) and tell the user OCR is unavailable.

## Real example
A 161x110 phone screenshot pushed to a public GitHub repo was fetched via `raw.githubusercontent.com` and OCR'd to the single legible string `Qwen3.6-27B-MTP` (a model name in a model-picker UI). See `references/github-screenshot-ocr.md` for the full transcript (incl. the GitHub no-auth fetch path).

## Note on vision models
If the environment ever provides a vision-capable tool, prefer it for scene/object understanding. Use this OCR fallback for text-in-images and when no vision tool is available.
