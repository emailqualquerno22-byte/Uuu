# Real example: OCR a screenshot pushed to a public GitHub repo

Context: user said "verify an image I just saved to my GitHub". No `gh` auth. Inside a Codespace.

## 1) Find the image without gh auth (public repo, zero token)
`gh auth status` -> not logged in. `GITHUB_REPOSITORY` env = `emailqualquerno22-byte/Uuu`.
`GITHUB_CODESPACE_TOKEN` is present but **returns 401 on api.github.com** -- do NOT use it for the REST API.

```bash
REPO="$GITHUB_REPOSITORY"   # emailqualquerno22-byte/Uuu

# recent commits (unauthenticated GET works for public repos)
curl -s -H "Accept: application/vnd.github+json" \
  "https://api.github.com/repos/$REPO/commits?per_page=5" -o /tmp/gh_commits.json
python3 -c "import json; d=json.load(open('/tmp/gh_commits.json'));
[print(c['sha'][:8], c['commit']['author']['date'], '|', c['commit']['message'].split(chr(10))[0][:60]) for c in d]"
# -> ef4f88f6 2026-07-14T13:36:25Z | Add files via upload   <-- today's upload

# files in that commit
LAST=$(python3 -c "import json; print(json.load(open('/tmp/gh_commits.json'))[0]['sha'])")
curl -s -H "Accept: application/vnd.github+json" \
  "https://api.github.com/repos/$REPO/commits/$LAST" -o /tmp/gh_last.json
python3 -c "import json; d=json.load(open('/tmp/gh_last.json'));
[print(f['filename'], '|', f['status']) for f in d.get('files',[])]"
# -> Screenshot_2026-07-14-10-29-55-57_e4424258c8b8649f6e67d283a50a2cbc.jpg | added
```

## 2) Resolve default branch (NOT main here)
```bash
BRANCH=$(curl -s -H "Accept: application/vnd.github+json" \
  "https://api.github.com/repos/$REPO" \
  | python3 -c "import json,sys; print(json.load(sys.stdin)['default_branch'])")
# -> session/agent_cd8fa3dc-...   (so raw at /main/ 404s; had to try main then master)
```

## 3) Fetch raw + verify it's an image
```bash
for BR in main master; do
  curl -sL "https://raw.githubusercontent.com/$REPO/$BR/Screenshot_2026-07-14-10-29-55-57_e4424258c8b8649f6e67d283a50a2cbc.jpg" \
    -o /workspaces/_github_imgs/screenshot.jpg -w "%{http_code}"
  file /workspaces/_github_imgs/screenshot.jpg | grep -q JPEG && break
done
# master -> 200, file = "JPEG image data ... 161x110"
```

## 4) Metadata + OCR
```bash
# EXIF via Pillow
# dims (161,110) RGB JPEG; Software: Android RMX3491_11_F.18  (Realme/OPPO phone)

tesseract /workspaces/_github_imgs/screenshot.jpg stdout --psm 11
# -> 'Qwen3.6-27B-MTP
```
Single legible string = a model name in a model-picker UI. Small screenshot -> rest is truncated.

## Lessons
- Public GitHub repos are readable with ZERO auth via `api.github.com` + `raw.githubusercontent.com`.
- `GITHUB_CODESPACE_TOKEN` != GitHub API token (401). Ignore it for repo reads.
- Always `file` the download -- a 404 returns HTML/ASCII, not the image.
- Default branch is frequently not `main`; resolve it or loop main -> master.
