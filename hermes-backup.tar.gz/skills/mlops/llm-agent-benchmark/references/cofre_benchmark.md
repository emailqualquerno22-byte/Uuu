# jogodocofre — the user's Cofre escape-room LLM benchmark

Repo: github.com/emailqualquerno22-byte/Uuu, folder `jogodocofre/`.
Server: `src/server.py` (Flask, REST + MCP on `/mcp`, port 5002, COFRE_PORT env).
Agent variants:
- `src/agente.py` — basic, NO memory, minimal prompt. Loops on format errors.
- `agente_plano.py` — memory (inventario) + anti-loop + deterministic end-game planner.
  Reads `API_URL/API_KEY/API_MODEL` from env; MODEL via `sys.argv[1]`, FASE `argv[2]`,
  MAX_ACOES `argv[3]`. Has `MAX_TOKENS` env.
- `run_cofre_modelo.py` — wraps agente.py for NVIDIA API (reads NVIDIA_API_KEY from
  `.hermes/.env`). NOTE: the "Mistral that won earlier" was `mistral-small-4-119b` via
  NVIDIA, not Groq — that's why the user remembered "NVIDIA".
- `run_cofre_groq.py` / `run_cofre_groq_plano.py` — CREATED this session: wrap the
  Groq OpenAI-compatible endpoint the same way.

## Game (cofre_fase1.py) — code is 319
- 1o digito (3): nro de canecas no armario da COZINHA (`abrir armario` → "tres canecas").
- 2o digito (1): numero riscado atras do QUADRO do ESCRITORIO (`examinar quadro`).
- 3o digito (9): papel na GAVETA TRANCADA do ESCRITORIO (precisa da chave).
- CHAVE: na gaveta do QUARTO (`ir para quarto` → `abrir gaveta` → `pegar chave`).
- Final: `usar chave em gaveta` (escritorio) → `abrir gaveta` → `digitar 319`.
- max_passos 200; reward -1/step, +100 ao abrir.

## Exact planner patch applied to agente_plano.py (this session, WORKS)
The 3 fragment planners were consolidated into ONE deterministic block right after
computing the flags, before `else: texto = call_llm(...)`:
```python
if tem_chave and tem_3 and tem_1 and tem_9:
    if sala != "escritorio":
        acoes = ["ir para sala", "ir para escritorio"]
    else:
        acoes = ["usar chave em gaveta", "abrir gaveta", "digitar 319"]
elif tem_chave and not tem_9:
    if not tem_1:
        acoes = ["ir para escritorio", "examinar quadro"] if sala != "escritorio" else ["examinar quadro"]
    else:
        acoes = (["ir para escritorio", "usar chave em gaveta", "abrir gaveta", "examinar gaveta"]
                 if sala != "escritorio"
                 else ["usar chave em gaveta", "abrir gaveta", "examinar gaveta"])
elif tem_chave and not tem_3:
    acoes = (["ir para cozinha", "abrir armario", "examinar armario"]
             if sala != "cozinha" else ["abrir armario", "examinar armario"])
elif not tem_chave and chamadas_llm >= 4:
    acoes = (["ir para quarto", "abrir gaveta", "examinar gaveta", "pegar chave"]
             if sala != "quarto" else ["abrir gaveta", "examinar gaveta", "pegar chave"])
else:
    texto = call_llm(obs, historico, inventario)
```
Flags: `tem_3="canecas" in inv_l`, `tem_1="atras" in inv_l`, `tem_9="9" in inv_l and "papel" in inv_l`,
`tem_chave="chave aqui" in inv_l`.

## CRITICAL BUG FIXED this session — key detection false-positive
`atualiza_inventario` originally tagged `[CHAVE AQUI]` whenever the result contained
"chave". That is WRONG: the bilhete says "abre com a chave" (mentions it, doesn't hold
it) and a failed pickup returns `Nao da pra pegar 'chave'.` (contains "pega"). Both
false-positived → planner skipped planner-chave and the game replied `Voce nao tem 'chave'`
forever. Fix (applied):
```python
if "pegar chave" in acao.lower() and (
    "voce pega:" in resultado.lower() or "voce pegou" in resultado.lower()):
    nota += " [CHAVE AQUI]"
```
After this fix a clean llama-3.3-70b run reaches the key via planner-chave, collects
3/1/9 via the consolidated planners, and digita 319 → VITÓRIA (deterministic).

## Model results this session (Groq, Fase 1)
- qwen/qwen3.6-27b + agente básico: loop de formato (asteriscos). FAIL.
- llama-3.3-70b + agente básico: frases com artigos. FAIL pre-prompt-fix.
- llama-3.1-8b-instant + agente básico: frases. FAIL.
- qwen/qwen3.6-27b + agente_plano: pior — ignora prefixo ACAO:, manda <think> como
  acao. FAIL. DO NOT use qwen3 with agente_plano.
- llama-3.3-70b + agente_plano (com planner consolidado + bug fix): PEGOU a chave,
  coletou 3/1/9, e vence deterministicamente. PREFERRED model for this eval.

## Run recipe
```bash
cd /workspaces/Uuu/jogodocofre
# terminal 1: server (needs flask/requests/python-dotenv; --break-system-packages ok on Codespaces)
python3 src/server.py
# terminal 2: agent (Groq) — run in background, poll the log
export GROQ_API_KEY="gsk_..."
python3 run_cofre_groq_plano.py "llama-3.3-70b-versatile" "cofre_fase1" 6
# poll: tail -14 logs_cofre_llama-3.3-70b-versatile_cofre_fase1.txt
#       grep -iE "planner|VITORIA|digitar 319" logs_*.txt
```
Groq free tier is SLOW (2-3 min/call under load) — a full win takes many minutes.
