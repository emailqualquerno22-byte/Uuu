# Agentic benchmarks for small/quantized open-weight models

## Why
To pick the best model for an HF Space (or any agentic task), compare **agentic
benchmarks**, not just raw size. The two that matter:

- **BFCL** (Berkeley Function Calling Leaderboard) — tool/function calling.
  v3 = GPT-4o baseline ~69.6 (Overall). v4 = newer, scores not directly comparable.
- **TAU-Bench** — multi-turn agentic (Retail / Airline). GPT-4o ≈ 62.8 / 46.0.

## How to research (no API key needed)
1. Fetch the model card README raw:
   `curl -sL https://huggingface.co/<repo>/raw/main/README.md`
2. Grep for `BFCL`, `TAU`, `function calling`, `agent` (case-insensitive).
3. **Model cards render benchmark tables as HTML** — plain `grep` often misses row
   labels. Strip tags (`re.sub(r"<[^>]+>","",txt)`) and print a window around the
   keyword to recover values.
4. The BFCL leaderboard page (gorilla.cs.berkeley.edu) renders via JS — there is **no
   static JSON endpoint** that works via curl. Rely on the model card numbers.

## Findings (verified 2026-07-13, from model cards)
| Model | Agentic benchmark | Note |
|---|---|---|
| **GLM-4-9B-0414** | BFCL-v3 69.6, TAU Retail 68.7 / Airline 51.2 | **Best agentic small model** (nível GPT-4o). Card tabs the 32B; 9B inherits same family. |
| **Qwen3.5-4B** | BFCL-V4 ~49.7/42.4/66.1, TAU2-Bench 57.4/41.9 | Strong, but numbers below GLM in the "General Agent" section. |
| Gemma-4-E2B (QAT) | mentions function calling / agentic | No BFCL number published. |
| Qwen2.5-3B, Llama-3.1-8B, Llama-3.2-3B, gemma-2-9b, Falcon3-3B, EXAONE-3.5-2.4B, Phi-3.5-mini, Qwen2.5-1.5B, SmolLM2-1.7B | **none** | No agentic benchmark in card. |

**Takeaway:** among small open-weights, GLM-4-9B is the strongest agentic choice;
Qwen3.5-4B is the runner-up. The rest don't document agentic capability.
