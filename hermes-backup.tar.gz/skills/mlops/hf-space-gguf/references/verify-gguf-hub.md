# Verifying GGUF availability + ad-hoc code verification

## 1) Confirm the GGUF exists and fits (before recommending/deploying)
The Hub serves files at `https://huggingface.co/<repo>/resolve/main/<file>`.
Use a HEAD request and read `content-length`:

```python
import subprocess
def gguf_size_mb(repo, file):
    r = subprocess.run(["curl","-sIL","-m","25",
        f"https://huggingface.co/{repo}/resolve/main/{file}"], capture_output=True, text=True)
    code=None; sz=None
    for l in r.stdout.splitlines():
        if l.lower().startswith("http/"): code=l.split()[1]
        if l.lower().startswith("content-length:"):
            try: sz=int(l.split(":")[1].strip())
            except: pass
    return code, (sz/1e6 if sz else None)
# reject if code != "200" or size > ~14 GB (headroom under 16 GB cpu-basic)
```
Gated repos may return 401 — prefer public GGUF repos (e.g. `unsloth/*-GGUF`).

## 2) Ad-hoc verify app.py when gradio/llama_cpp aren't installed locally
Mock the heavy modules, import the real file, exercise logic, then clean up.
Run from `/tmp` with a `hermes-verify-` prefix and remove after.

```python
import sys, os, types, importlib.util
ok=True
def check(m,c,e=""):
    global ok; print(("PASS" if c else "FAIL"), m, e); ok=ok and c
calls={"dl":None,"llm":0}
class FakeLlama:
    def __init__(self, model_path, n_ctx, n_threads, n_batch, verbose):
        calls["llm"]+=1
        self.n_ctx=n_ctx; self.n_threads=n_threads
    def create_chat_completion(self, messages, max_tokens, temperature, stop):
        return {"choices":[{"message":{"content":f"ECHO:{messages[-1]['content']}"}}]}
class FakeHF:
    def hf_hub_download(self, repo_id, filename):
        calls["dl"]=(repo_id,filename); return f"/tmp/fake_{filename}"
sys.modules["gradio"]=types.ModuleType("gradio")
sys.modules["gradio"].Blocks=type("B",(),{"__init__":lambda s,*a,**k:None,"__enter__":lambda s:s,"__exit__":lambda s,*a:None})
sys.modules["gradio"].ChatInterface=lambda fn,fill_height=None:None
sys.modules["gradio"].Markdown=lambda *a,**k:None
sys.modules["llama_cpp"]=types.ModuleType("llama_cpp"); sys.modules["llama_cpp"].Llama=FakeLlama
hf=types.ModuleType("huggingface_hub"); hf.hf_hub_download=FakeHF().hf_hub_download
sys.modules["huggingface_hub"]=hf
spec=importlib.util.spec_from_file_location("app","<path>/app.py")
app=importlib.util.module_from_spec(spec); spec.loader.exec_module(app)
check("repo", app.MODEL_REPO=="<expected>")
check("file", app.MODEL_FILE=="<expected>")
check("respond", "ECHO" in app.respond("x",[("a","b")]))
app.get_llm(); app.get_llm()
check("cached", calls["llm"]==1)
check("dl repo", calls["dl"][0]==app.MODEL_REPO)
import py_compile
try: py_compile.compile("<path>/app.py", doraise=True); check("compile",True)
except Exception as e: check("compile",False,str(e))
# ALSO do the real HEAD check from section 1 for the actual GGUF url.
print("AD-HOC:", "TODOS PASS" if ok else "FALHAS"); sys.exit(0 if ok else 1)
```

## Honesty note
This proves **logic only**. The real Gradio launch + multi-GB GGUF load on CPU is
unconfirmed until the Space is deployed. Always state this; never claim "suite green".
