---
name: hf-space-gguf
description: Deploy open-weight GGUF (quantized) LLMs to a free Hugging Face Space (Gradio + llama-cpp-python, CPU tier). Covers model/quant selection by agentic capability, verifying GGUF availability/size on the Hub, scaffolding the Space, ad-hoc verification when deps aren't installed, and the BFCL/TAU-Bench research to pick the best model. Use when the user wants to run a model "for free" on HF, build an HF Space chat app, or choose a small quantized model by agentic benchmark.
---

# HF Space — GGUF quantized LLM (free CPU tier)

Deploy an open-weight model quantized to GGUF (Q4 etc.) on a **free HF Space**
(cpu-basic: 2 vCPU / 16 GB RAM, no GPU, no cost) using `llama-cpp-python` + Gradio.
The model is downloaded from the Hub on first load and cached.

## When to use
- User: "roda um modelo de graça no HF", "cria um Space", "modelo quantizado na nuvem grátis".
- User wants to pick a small/quantized model by **agentic capability** (BFCL, TAU-Bench).
- Building a chat app that runs entirely server-side without API keys per request.

## Workflow
1. **Pick model + quant.** Among small open-weights, prefer the one with documented
   agentic benchmarks. See `references/gguf-benchmarks.md` (method + findings:
   GLM-4-9B-0414 is the strongest agentic small model — BFCL 69.6 / TAU nível GPT-4o).
2. **Verify the GGUF exists AND its size** on the Hub *before* recommending it.
   Technique in `references/verify-gguf-hub.md` (HEAD on the `/resolve/main/` URL,
   parse `content-length`). Reject anything > ~14 GB (leaves headroom under 16 GB).
   Q4_K_M = best quality/size; Q4_0 / Q3_K_M smaller but lower quality.
3. **Scaffold the Space.** Copy `templates/app.py`, `templates/requirements.txt`,
   `templates/README.md`. `app.py` is model-agnostic: set `MODEL_REPO`/`MODEL_FILE`
   (env-overridable) and tune `N_THREADS=2`, `N_CTX=4096` for cpu-basic.
4. **Ad-hoc verify** the scaffold even though `gradio`/`llama_cpp` aren't installed
   locally (see `references/verify-gguf-hub.md` for the mock-import recipe). Always
   also confirm the GGUF URL returns HTTP 200 via HEAD.
5. **Deploy.** Needs `HF_TOKEN` with write perms. NOTE: `huggingface-cli` is
   DEPRECATED — prefer the newer `hf` CLI:
   - `hf auth whoami` → if "Not logged in", no token stored (don't attempt upload).
   - `hf auth login --token $HF_TOKEN` (or `hf auth login` for browser flow).
   - `hf upload USER/SPACE ./dir --repo-type space --private`
   - Older fallback: `huggingface-cli login` → `huggingface-cli upload ...`.
   Or create the Space on the site (SDK=Gradio, Hardware=CPU free) then `git push`.

## Pitfalls
- **HF_TOKEN empty/absent → no automatic deploy.** Build the structure and hand the
  user the manual deploy command; don't claim it's "live". Verify token presence
  (non-empty value, not just the var name) before attempting upload. Concretely:
  `hf auth whoami` should NOT print "Not logged in"; if it does, `hf upload` fails
  with `401 Unauthorized` on `api/repos/create` — don't waste a call, ask the user
  for the token first.
- **Ad-hoc verification ≠ real run.** Mocking `gradio`/`llama_cpp` proves logic only.
  The actual Gradio launch + 6 GB GGUF load on CPU is unconfirmed until deployed.
  State this honestly; never say "suite green".
- **Model-card benchmark tables are HTML**, not clean markdown — `grep`/README fetch
  often misses row labels. Clean `<[^>]+>` tags and read the surrounding window; the
  BFCL leaderboard page renders via JS (no static JSON) — rely on the model card.
- **`/resolve/main/<file>` may 401** for gated repos; use a non-gated GGUF (e.g.
  `unsloth/*-GGUF`) for public Spaces.
- **Q4_K_M of a 9B model ≈ 6 GB** — fine on 16 GB but slower than a 3B (~2.7 GB) on
  2 vCPU. Offer the lighter quant if the user prioritizes responsiveness.

## Support files
- `templates/app.py` — lazy-load GGUF, chat interface, env-overridable model.
- `templates/requirements.txt` — gradio + llama-cpp-python + huggingface_hub.
- `templates/README.md` — Space doc with model table + deploy command.
- `references/gguf-benchmarks.md` — how to research BFCL/TAU + concrete findings.
- `references/verify-gguf-hub.md` — HEAD-size check + ad-hoc mock verification recipe.
