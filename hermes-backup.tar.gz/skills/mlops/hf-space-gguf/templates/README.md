---
title: Modelo Quantizado Grátis (GGUF Q4)
emoji: 🤗
colorFrom: blue
colorTo: green
sdk: gradio
sdk_version: "4.44.0"
app_file: app.py
pinned: false
duplicates: false
---

# 🤗 Modelo Quantizado na CPU Grátis do Hugging Face

Este Space roda um modelo de linguagem **open-weight quantizado (GGUF Q4)** inteiramente
na **CPU grátis** do Hugging Face (tier `cpu-basic`: 2 vCPU / 16 GB RAM). Nenhum GPU,
nenhuma cobrança.

## Como funciona
- `app.py` usa `llama-cpp-python` para carregar um arquivo `.gguf` do Hub.
- O modelo é baixado **sob demanda** no primeiro load (cacheado pelo Hub).
- `n_ctx` e `n_threads` são ajustados para a CPU pequena do tier grátis.

## Trocar o modelo (sem editar código)
Edite as variáveis no topo do `app.py`:
```python
MODEL_REPO = "unsloth/Qwen3.5-4B-GGUF"
MODEL_FILE = "Qwen3.5-4B-Q4_K_M.gguf"
```
Ou defina Secrets no Space: `MODEL_REPO` e `MODEL_FILE`.

## Deploy
```bash
pip install -U "huggingface_hub[cli]"
huggingface-cli login   # cole o token com permissao de escrita
huggingface-cli upload SEU_USUARIO/hf-quantizado-gratis ./hf_quantized_space \
    --repo-type space --private
```
Ao criar pelo site, escolha **SDK: Gradio** e **Hardware: CPU (grátis)**.
