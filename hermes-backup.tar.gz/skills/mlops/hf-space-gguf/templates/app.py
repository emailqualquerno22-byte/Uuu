#!/usr/bin/env python3
"""HF Space: roda um modelo GGUF Q4 inteiramente na CPU grátis do Hugging Face.

Carrega o .gguf sob demanda (cacheado), serve chat via Gradio.
Ajustado para o tier cpu-basic (2 vCPU / 16 GB): n_threads=2, n_ctx moderado.
"""
import os
import threading
import gradio as gr
from huggingface_hub import hf_hub_download
from llama_cpp import Llama

# ---- Configuração do modelo (edite aqui ou via Secrets do Space) ----
# Padrao: GLM-4-9B-0414 (melhor modelo agentico da lista: BFCL 69.6 / TAU-Bench
# nivel GPT-4o). Q4_K_M = 6.2 GB, cabe no tier cpu-basic (16 GB). Para mais
# velocidade na CPU gratis, troque por Q4_0 (5.5 GB) ou Q3_K_M (5.0 GB).
MODEL_REPO = os.environ.get("MODEL_REPO", "unsloth/GLM-4-9B-0414-GGUF")
MODEL_FILE = os.environ.get("MODEL_FILE", "GLM-4-9B-0414-Q4_K_M.gguf")
N_CTX = int(os.environ.get("N_CTX", "4096"))
N_THREADS = int(os.environ.get("N_THREADS", "2"))     # cpu-basic tem 2 vCPU
MAX_TOKENS = int(os.environ.get("MAX_TOKENS", "512"))

_llm = None
_lock = threading.Lock()


def get_llm():
    """Carrega o modelo uma única vez (lazy), com cache de thread."""
    global _llm
    if _llm is None:
        with _lock:
            if _llm is None:
                print(f"[load] baixando {MODEL_REPO}/{MODEL_FILE} ...", flush=True)
                path = hf_hub_download(repo_id=MODEL_REPO, filename=MODEL_FILE)
                print(f"[load] arquivo em {path}", flush=True)
                _llm = Llama(
                    model_path=path,
                    n_ctx=N_CTX,
                    n_threads=N_THREADS,
                    n_batch=512,
                    verbose=False,
                )
                print("[load] pronto.", flush=True)
    return _llm


def respond(message, history):
    llm = get_llm()
    messages = []
    for user, bot in (history or []):
        if user:
            messages.append({"role": "user", "content": user})
        if bot:
            messages.append({"role": "assistant", "content": bot})
    messages.append({"role": "user", "content": message})

    out = llm.create_chat_completion(
        messages=messages,
        max_tokens=MAX_TOKENS,
        temperature=0.7,
        stop=["<|im_end|>"],
    )
    return out["choices"][0]["message"]["content"]


with gr.Blocks(title="Modelo Quantizado Grátis") as demo:
    gr.Markdown(f"# 🤗 {MODEL_REPO.split('/')[-1]} (Q4, CPU grátis)\n"
                f"Modelo: `{MODEL_REPO}/{MODEL_FILE}`")
    gr.ChatInterface(respond, fill_height=True)

if __name__ == "__main__":
    demo.launch()
