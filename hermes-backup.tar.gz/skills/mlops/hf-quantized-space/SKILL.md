---
name: hf-quantized-space
description: "Deploy a quantized GGUF LLM to a free Hugging Face Space (CPU tier) via Gradio + llama-cpp-python. Includes ready templates, verified model sizes, and ad-hoc verification when deps are absent."
version: 1.0.0
author: Hermes session
license: MIT
tags: [huggingface, hf-space, gguf, quantization, llm-deploy, cpu-inference, free-tier, gradio, llama-cpp]
platforms: [linux, macos, windows]
---

# HF Quantized Space — LLM na CPU grátis do Hugging Face

Use esta skill quando o usuário quiser **rodar um modelo de linguagem open-weight
quantizado (GGUF) na nuvem gratuita do Hugging Face** — sem GPU, sem custo — ou
perguntar "dá pra rodar modelo quantizado no HF de graça". Complementa `llama-cpp`
(infra local/server) cobrindo o caso "modelo na nuvem HF gratuita".

## Quando usar
- "Quero rodar um modelo quantizado no Hugging Face de graça / na nuvem"
- Montar um Space Gradio que serve chat com um GGUF Q4 na CPU
- Usuário quer testar LLMs open-weight sem GPU local

## Restrições do tier cpu-basic (dictam os params)
- **2 vCPU** → `n_threads=2`, `n_batch=512`
- **16 GB RAM** → GGUF descomprimido deve caber; teto prático ~5-6 GB (lento acima disso)
- **sem GPU** → `n_gpu_layers=0` (default CPU)
- Gargalo é CPU, não RAM: modelos menores = mais responsivos

## Estrutura do Space (pasta `hf_quantized_space/`)
- `app.py` — template em `templates/hf_space_app.py` (Gradio + `llama-cpp-python`, lazy-load)
- `requirements.txt` — `gradio==4.44.0`, `llama-cpp-python==0.3.9`, `huggingface_hub>=0.25.0`
- `README.md` — `sdk: gradio`, `sdk_version: "4.44.0"`, `app_file: app.py`, `pinned: false`
- `.gitignore` — `__pycache__/`, `*.pyc`, `*.gguf`

## Passos
1. Escolher modelo (ver `references/hf-space-cpu.md` para tabela verificada + como medir tamanho).
2. Copiar `templates/hf_space_app.py` → `app.py`; ajustar `MODEL_REPO`/`MODEL_FILE` (ou via Secrets).
3. `py_compile app.py` para validar sintaxe.
4. Re-confirmar via API que o `.gguf` alvo existe no repo.
5. Deploy (precisa `HF_TOKEN` com permissão de escrita):
   ```bash
   pip install -U "huggingface_hub[cli]"
   huggingface-cli login        # cole o token
   huggingface-cli upload SEU_USUARIO/hf-quantizado-gratis ./hf_quantized_space \
       --repo-type space --private
   ```
   Ou crie o Space no site (SDK: Gradio, Hardware: CPU grátis) e `git push`.
   No site, defina Secrets `MODEL_REPO`/`MODEL_FILE` para trocar modelo sem editar código.

## Verificação AD-HOC quando deps pesadas ausentes (gradio/llama_cpp não instalados localmente)
O app não roda local sem as libs, mas a LÓGICA é validável com mocks (ver
`references/hf-space-cpu.md` → seção "Verificação AD-HOC"). Resumo:
- Injete em `sys.modules` fakes de `gradio`, `llama_cpp`, `huggingface_hub`.
- `importlib.util.spec_from_file_location` + `exec_module(app)` para carregar o app real.
- Assert: defaults, `respond()` formata chatml, `get_llm()` cacheia (1 instância),
  `hf_hub_download` chamado com repo/file certos, override por env, `py_compile`,
  existência do `.gguf` no repo. Script em `/tmp/hermes-verify-*.py`, removido após.
- Isto prova a lógica — NÃO a subida real (que exige HF_TOKEN + deploy).

## Pitfalls
- `HF_TOKEN` vazio/placeholder no `.env` bloqueia `hf upload` — verifique valor não-vazio antes.
- LSP acusa `import gradio`/"import llama_cpp" não resolvido localmente: é só falta de dep
  do Space, não erro real; `py_compile` passa. Não trate como erro.
- Modelo baixado no primeiro load do Space (pode demorar ~minutos no deploy inicial).
- API `?full=true` NÃO retorna `size` de siblings GGUF — use HEAD no `resolve/main/<file>.gguf`.

## References
- **[hf-space-cpu.md](references/hf-space-cpu.md)** — tabela de modelos verificados que cabem no tier, como medir tamanho real, receita de deploy, técnica de verificação ad-hoc.

## Templates
- **[hf_space_app.py](templates/hf_space_app.py)** — `app.py` pronto (Gradio + llama-cpp-python, lazy-load thread-safe, modelo via env/Secrets).
