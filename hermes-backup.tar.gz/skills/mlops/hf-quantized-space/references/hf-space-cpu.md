# HF Space gratuito rodando GGUF Q4 na CPU

Receita para subir um modelo de linguagem open-weight **quantizado (GGUF Q4)**
inteiramente na **CPU grátis** do Hugging Face (tier `cpu-basic`: 2 vCPU / 16 GB RAM).
Sem GPU, sem cobrança. Complementa o `llama-cpp` cobrindo o caso "modelo na nuvem HF gratuita".

## Estrutura do Space (pasta `hf_quantized_space/`)
- `app.py` — template em `templates/hf_space_app.py` (Gradio + `llama-cpp-python`)
- `requirements.txt` — `gradio==4.44.0`, `llama-cpp-python==0.3.9`, `huggingface_hub>=0.25.0`
- `README.md` — `sdk: gradio`, `sdk_version: "4.44.0"`, `app_file: app.py`, `pinned: false`
- `.gitignore` — `__pycache__/`, `*.pyc`, `*.gguf`

## Restrições do tier cpu-basic (dictam os params)
- **2 vCPU** → `n_threads=2`, `n_batch=512`
- **16 GB RAM** → o GGUF descomprimido deve caber; teto prático ~5-6 GB (ex.: gemma-2-9b Q4_K_M = 5.8 GB roda mas lento)
- **sem GPU** → `n_gpu_layers=0` (default em CPU)
- Gargalo é CPU, não RAM: modelos menores = mais responsivos

## Verificar tamanhos reais antes de escolher (HEAD no arquivo .gguf)
```bash
curl -sIL "https://huggingface.co/<repo>/resolve/main/<file>.gguf" | grep -i content-length
```
A API `?full=true` NÃO retorna `size` dos siblings GGUF — use o HEAD acima ou a
tree API (`/api/models/<repo>/tree/main`) que traz `size` em alguns casos.

## Modelos verificados que cabem no tier grátis (tamanhos reais, 2026-07-13)
| Repo GGUF | Arquivo Q4 | Tamanho | Nota |
|---|---|---|---|
| `unsloth/Qwen3.5-4B-GGUF` | `Qwen3.5-4B-Q4_K_M.gguf` | 2.7 GB | ⭐ mais baixado (1.1M), forte PT-BR |
| `bartowski/Falcon3-3B-Instruct-abliterated-GGUF` | `Falcon3-3B-Instruct-abliterated-Q4_K_M.gguf` | 2.0 GB | leve/rápido |
| `lmstudio-community/EXAONE-3.5-2.4B-Instruct-GGUF` | `EXAONE-3.5-2.4B-Instruct-Q4_K_M.gguf` | 1.6 GB | pequeno |
| `bartowski/Meta-Llama-3.1-8B-Instruct-GGUF` | `Meta-Llama-3.1-8B-Instruct-Q4_K_M.gguf` | 4.9 GB | mais capaz, lento |
| `bartowski/gemma-2-9b-it-GGUF` | `gemma-2-9b-it-Q4_K_M.gguf` | 5.8 GB | teto da RAM |
| `Qwen/Qwen2.5-3B-Instruct-GGUF` | `qwen2.5-3b-instruct-q4_k_m.gguf` | 2.1 GB | equilíbrio |
| `Qwen/Qwen2.5-1.5B-Instruct-GGUF` | `qwen2.5-1.5b-instruct-q4_k_m.gguf` | 1.1 GB | rápido |
| `bartowski/SmolLM2-1.7B-Instruct-GGUF` | `SmolLM2-1.7B-Instruct-Q4_0.gguf` | 1.0 GB | mais leve |

Recomendação padrão: **Qwen3.5-4B Q4_K_M** (qualidade/velocidade). Q4_K_M é o ponto
ótimo (mínima perda); Q3_K_M/Q2_K cabem mais mas perdem qualidade. Gemma-4-E2B QAT
q4_0 (Google treinou já quantizado) ~3.3 GB tem qualidade quase FP16.

## Deploy (precisa HF_TOKEN com permissão de escrita)
```bash
pip install -U "huggingface_hub[cli]"
huggingface-cli login        # cole o token (https://huggingface.co/settings/tokens)
huggingface-cli upload SEU_USUARIO/hf-quantizado-gratis ./hf_quantized_space \
    --repo-type space --private
```
Ou crie o Space no site (SDK: Gradio, Hardware: CPU grátis) e `git push` a pasta.
No site, defina Secrets `MODEL_REPO` / `MODEL_FILE` para trocar o modelo sem editar código.

## Verificação AD-HOC sem as deps pesadas (gradio/llama_cpp ausentes no ambiente local)
O app não roda local sem as libs, mas dá pra validar a LÓGICA com mocks:
1. Injete em `sys.modules` módulos fake de `gradio`, `llama_cpp`, `huggingface_hub`
   (FakeLlama ecoa `n_ctx/n_threads`; hf_hub_download retorna path fake).
2. `importlib.util.spec_from_file_location` + `exec_module(app)` para carregar o app real.
3. Assert: defaults, `respond()` formata histórico chatml e devolve texto, `get_llm()`
   cacheia (1 instância), `hf_hub_download` chamado com repo/file certos, override por env.
4. `py_compile` + re-confirmar via API que o `.gguf` alvo existe no repo.
Script temporário em `/tmp/hermes-verify-*.py`, removido após o run.
Isso prova a lógica — NÃO a subida real (que exige HF_TOKEN + deploy).

## Pitfalls
- `HF_TOKEN` vazio no `.env` (placeholder) bloqueia `hf upload` — verifique valor não-vazio antes.
- `app.py` importa `gradio`/`llama_cpp` ausentes localmente → LSP acusa import não resolvido,
  mas é só falta de dep do Space; `py_compile` passa. Não trate como erro real.
- O modelo é baixado no primeiro load (pode demorar ~minutos no deploy inicial).
