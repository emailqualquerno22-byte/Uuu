#!/usr/bin/env python3
"""HF Space template: roda um modelo GGUF Q4 inteiramente na CPU gratis do HF.

Carrega o .gguf sob demanda (cacheado), serve chat via Gradio.
Ajustado para o tier cpu-basic (2 vCPU / 16 GB): n_threads=2, n_ctx moderado.
Copie para a pasta do Space como app.py junto com README.md + requirements.txt.
"""
import os
import threading
import gradio as gr
from huggingface_hub import hf_hub_download
from llama_cpp import Llama

# ---- Configuracao do modelo (edite aqui ou via Secrets do Space) ----
MODEL_REPO = os.environ.get("MODEL_REPO", "unsloth/Qwen3.5-4B-GGUF")
MODEL_FILE = os.environ.get("MODEL_FILE", "Qwen3.5-4B-Q4_K_M.gguf")
N_CTX = int(os.environ.get("N_CTX", "4096"))
N_THREADS = int(os.environ.get("N_THREADS", "2"))     # cpu-basic tem 2 vCPU
MAX_TOKENS = int(os.environ.get("MAX_TOKENS", "512"))

_llm = None
_lock = threading.Lock()


def get_llm():
    """Carrega o modelo uma unica vez (lazy), com cache de thread."""
    global _llm
    if _llm is None:
        with _lock:
            if _llm is None:
                print(f"[load] baixando {MODEL_REPO}/{MODEL_FILE} ...", flush=True)
                path = hf_hub_download(repo_id=MODEL_REPO, filename=MODEL_FILE)
                print(f"[load] arquivo em {path}", flush=True)
                _llm = Llama(
                    model_path=path,
                    n_ctx=N_CTX,
                    n_threads=N_THREADS,
                    n_batch=512,
                    verbose=False,
                )
                print("[load] pronto.", flush=True)
    return _llm


def respond(message, history):
    llm = get_llm()
    messages = []
    for user, bot in (history or []):
        if user:
            messages.append({"role": "user", "content": user})
        if bot:
            messages.append({"role": "assistant", "content": bot})
    messages.append({"role": "user", "content": message})

    out = llm.create_chat_completion(
        messages=messages,
        max_tokens=MAX_TOKENS,
        temperature=0.7,
        stop=["<|im_end|>"],
    )
    return out["choices"][0]["message"]["content"]


with gr.Blocks(title="Modelo Quantizado Gratis") as demo:
    gr.Markdown(f"# Hugging Face {MODEL_REPO.split('/')[-1]} (Q4, CPU gratis)\n"
                f"Modelo: `{MODEL_REPO}/{MODEL_FILE}`")
    gr.ChatInterface(respond, fill_height=True)

if __name__ == "__main__":
    demo.launch()
