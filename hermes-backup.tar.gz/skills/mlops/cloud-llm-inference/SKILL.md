---
name: cloud-llm-inference
description: Use cloud/hosted LLM APIs (Groq, OpenRouter, etc.) as an inference backend when local RAM is insufficient or a provider is out of credits. Covers API-key validation, the Qwen3 "thinking mode" token pitfall, and safe key handling. Trigger when the user has a cloud API key, wants a fast hosted model, or local models OOM.
---

# Cloud LLM Inference (Groq / OpenRouter / hosted)

Use hosted LLM APIs as an alternative to local Ollama when:
- Local RAM is too small for a model (this machine: ~4.8 GB free, no GPU — anything >~5.5 GB won't run).
- The user's default provider is out of credits (e.g. OpenRouter free tier exhausted / ~0 balance).
- You need low latency on a strong model without local compute.

## Groq (good free-tier fallback)

Groq exposes an OpenAI-compatible endpoint at `https://api.groq.com/openai/v1`.
Free tier, fast (often 1000+ tokens/s output), models with 131k context window.

Validate a key before doing anything else:
```
curl -s -o /tmp/groq_models.json -w "HTTP %{http_code}\n" \
  https://api.groq.com/openai/v1/models \
  -H "Authorization: Bearer $GROQ_API_KEY"
# HTTP 200 = valid; 401 "Invalid API Key" = bad key
```

List text models (filter to chat-capable):
```python
import json
d = json.load(open('/tmp/groq_models.json'))
for m in d['data']:
    if 'text' in m.get('input_modalities',[]) and 'text' in m.get('output_modalities',[]):
        print(m['id'], m.get('context_window'))
```

Notable free text models on Groq (verified 2026-07):
- `llama-3.3-70b-versatile` (70B, strong)
- `meta-llama/llama-4-scout-17b-16e-instruct` (Llama 4)
- `qwen/qwen3-32b`, `qwen/qwen3.6-27b` (Qwen 3 — see pitfall below)
- `llama-3.1-8b-instant` (fast)

### PITFALL: Qwen3 "thinking" mode eats your tokens
Qwen3 models have native reasoning. If you call them with a small `max_tokens`,
the model spends ALL its tokens inside a `<think>...</think>` block and never
emits the final answer (finish_reason = "length", not "stop").

Two fixes, pick one:
1. Disable reasoning: pass `"reasoning_effort": "none"` in the request body.
2. OR raise `max_tokens` high enough (e.g. 400+) so the answer fits after thinking.

After disabling reasoning, strip any leftover `<think>` tags from the response:
```python
import re
msg = re.sub(r'<think>.*?</think>', '', msg, flags=re.S).strip()
```

Working chat call (reasoning off):
```bash
curl -s https://api.groq.com/openai/v1/chat/completions \
  -H "Authorization: Bearer $GROQ_API_KEY" \
  -H "Content-Type: application/json" \
  -d '{"model":"qwen/qwen3.6-27b","messages":[{"role":"user","content":"Oi"}],
       "temperature":0.6,"max_tokens":400,"reasoning_effort":"none"}'
```

## Safe API-key handling (CRITICAL)
- NEVER print the raw key in chat, write it to a file, or commit it to git.
- Prefer passing via env var: `export GROQ_API_KEY="..."` then `$GROQ_API_KEY` in curl, or `os.environ["GROQ_API_KEY"]` in Python.
- Treat any `gsk_...` / `sk-...` string as a password. Tell the user to keep it safe.
- Don't paste the key literally into code that might go to version control.

## When to choose local vs cloud
- Local (Ollama) preferred for privacy/offline and small models (qwen2.5:3b = ~1.9 GB fits).
- Cloud (Groq) preferred when the model is too big for RAM or you need speed without burning local resources.
- If a user's OpenRouter key has ~0 credits and the daily free limit is exhausted, Groq free tier is the natural fallback — verify the key is valid first.
