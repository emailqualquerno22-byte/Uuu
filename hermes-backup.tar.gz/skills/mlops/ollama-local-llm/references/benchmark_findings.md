# Benchmark findings: agentic capability & OpenAI-tier mapping

Condensed, verified knowledge from a session comparing GLM/Kimi open-weight
models against OpenAI on agentic benchmarks. Use as a fast lookup; always
re-confirm against the live model card when a specific number matters.

## Agentic benchmarks to cite (in priority order)
- **BFCL-v3** (Berkeley Function Calling Leaderboard): Overall + MultiTurn.
  Direct measure of tool/function-calling skill.
- **TAU-Bench** (Retail / Airline): multi-step agentic tasks with a database
  + tool loop. Best "agent" proxy.
- **SWE-bench Verified**: code-agent (fixing real GitHub issues).
- **IFEval**: instruction following (weak agent signal, but cards quote it).

## Verified numbers (GLM-4-0414 family, from official zai-org card)
The card publishes agentic scores for the **32B** variant; the **9B** shares
the same 0414 post-training (function calling) but has NO published agentic
score of its own (expect lower than 32B).

| Benchmark            | GLM-4-32B-0414 | GPT-4o-1120 | DeepSeek-V3-0324 |
|----------------------|----------------|-------------|------------------|
| IFEval               | 87.6           | 81.9        | 83.4             |
| BFCL-v3 Overall      | 69.6           | 69.6 (tie)  | 66.2             |
| BFCL-v3 MultiTurn    | 41.5           | 41.0        | 35.8             |
| TAU-Bench Retail     | 68.7           | 62.8        | 60.7             |
| TAU-Bench Airline    | 51.2           | 46.0        | 32.4             |
| SWE-bench Verified   | 33.8           | —           | —                |

**Takeaway:** GLM-4-32B **matches or beats GPT-4o** on agentic. The 9B is the
GPT-4o-mini-class sibling (inferred, not published).

## Size → OpenAI-tier mapping (for "which OpenAI model is it like?")
- ~9B open-weight (e.g. GLM-4-9B, Qwen2.5-7B, Llama-3.1-8B) ≈ **GPT-4o-mini**.
- ~32B open-weight (e.g. GLM-4-32B, Qwen2.5-32B) ≈ **GPT-4o** (can match on agentic).
- Frontier proprietary (GPT-5.x, Claude Opus/Sonnet) → **no open-weight peer** at 9–32B.
  Reachable only via paid API (OpenRouter `openai/gpt-5.x` or vendor key).

## Reality-check notes (avoid fabrication)
- "GPT-5.1" is NOT a real model name. The real OpenAI line is `gpt-5.x`
  (seen on OpenRouter: `gpt-5.4-nano`, `gpt-5.5`, `gpt-5.6-*`). If a user
  says "GPT-5.1", correct it and anchor to the closest REAL tier.
- Live BFCL/TAU leaderboard sites often DON'T resolve from the agent env
  (curl returns 000). Prefer the model card's own comparison table.
- Smaller agentic-capable models that FIT HF free tier (<14 GB Q4):
  GLM-4-9B-0414 (6.17 GB Q4, `inference: warm` on HF serverless) and
  Moonlight-16B-A3B (10.5 GB Q4, MMLU 70.0 but NO published BFCL/TAU).
  glm-edge-4b-chat (~2.2 GB) is too small to have agentic evidence.
