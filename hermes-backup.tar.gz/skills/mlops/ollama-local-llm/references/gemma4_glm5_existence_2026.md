# Gemma 4 / GLM 5.2 existence & sizing — verified 2026-07-13

Measured directly this session via Ollama registry probes, Hugging Face hub
API, and a live OpenRouter key. Use these as ground truth instead of guessing.

## Gemma 4 (EXISTS — corrected from earlier skill draft)
Ollama tags (HTTP 200 = real): `gemma4:latest` (9.61 GB), `gemma4:e2b`
(7.16 GB), `gemma4:e4b` (9.61 GB), `gemma4:12b` (7.56 GB), `gemma4:26b`,
`gemma4:31b`, `gemma4:cloud`.
- `gemma4:1b / 2b / 4b / 8b` → all 404 (NO small Gemma 4 tag).
- HF GGUF: `google/gemma-4-12B-it-qat-q4_0-gguf` ≈ 6.0 GB;
  `unsloth/gemma-4-26B-A4B-it-qat-GGUF` (UD-Q4_K_XL) ≈ 14 GB.
- Verdict for a <5 GB-free machine: none fit. Local fallback = `gemma3:1b`.

## GLM 5.2 (EXISTS)
- OpenRouter: `z-ai/glm-5.2` (ctx 1,048,576, ~$0.0000006/tok, confirmed).
  Also `z-ai/glm-5.1`, `z-ai/glm-5`, `z-ai/glm-5-turbo`, `z-ai/glm-5v-turbo`.
- HF GGUF: `unsloth/GLM-5.2-GGUF`. Smallest quant = UD-IQ2_XXS, but it is a
  SHARDED giant: 6 parts × ~49 GB ≈ **238 GB total**. Cannot run locally on
  normal hardware. Cloud API is the only viable route.
- Local-fit GLM on Ollama = `glm4:9b` (5.46 GB) — note glm-5 is NOT on Ollama.

## OpenRouter key reality (Hermes)
- Key is NOT in env (`OPENROUTER_API_KEY` unset). It lives in
  `~/.hermes/auth.json` → `credential_pool.openrouter[].access_token`
  (source `manual`). Extract with python, never print the value.
- "Key present" ≠ "usable":
  - Free models: 50 req/day hard cap. Exhausted → HTTP 429
    `Rate limit exceeded: free-models-per-day` (`X-RateLimit-Remaining: 0`).
  - Paid models with ~0 credits → HTTP 402 "can only afford N tokens".
- Gemma 4 free options on OpenRouter: `google/gemma-4-26b-a4b-it:free`,
  `google/gemma-4-31b-it:free` (both ctx 262144) — subject to the free cap.

## HF token
- Still an empty placeholder in this environment. HF Inference API / Spaces
  deploy remain blocked unless a real `HF_TOKEN` is supplied.

## What actually worked this session
- `ollama pull gemma3:1b` (815 MB) → success, runs in Portuguese.
- `ollama pull glm4:9b` (5.46 GB) → success (tight but fits ~4.8 GB free).
- OpenRouter `GET /api/v1/models` with the auth.json key → lists Gemma 4 / GLM 5.2.
- OpenRouter chat completion calls → blocked by 429 (free cap) + 402 (no credit).
