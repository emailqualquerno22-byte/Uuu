# Cloud-tier routing: where can a named model actually run?

Companion to SKILL.md §7. Durable findings from a session where the user wanted
GLM-5.2 / Kimi-2.6 / Kimi-2.7 locally and via HuggingFace "free cloud".

## 1. Ollama availability check (authoritative)
`timeout 8 ollama pull <name>` → exists if it starts downloading blobs;
`Error: pull model manifest: file does not exist` (registry 404) if ghost.
Note: `https://ollama.com/library/<name>` returns HTTP 200 for UNPUBLISHED
pre-announcement pages — a 200 is NOT proof the weights exist.

Specific result: `glm-5.2`, `kimi-k2.6`, `kimi-k2.7-code` → 404 (not on Ollama).
`glm-4.7-flash` → exists but 19 GB (too big for low-RAM machines).

## 2. OpenRouter (cloud API, no download)
Public, no-auth model list: `GET https://openrouter.ai/api/v1/models`
Returns `{data:[{id, context_length, pricing:{prompt,completion}}]}`.
Confirmed present (real session):
- `z-ai/glm-5.2`        ctx 1,048,576  ~$0.93 / 1M inp
- `moonshotai/kimi-k2.6` ctx 262,144   ~$0.66 / 1M inp
- `moonshotai/kimi-k2.7-code` ctx 262,144 ~$0.72 / 1M inp
Also `z-ai/glm-5`, `z-ai/glm-4.7`, `moonshotai/kimi-k2`, etc.
Viable path for giant models: call via `OPENROUTER_API_KEY`, nothing downloaded.

## 3. HuggingFace free-tier limits (hard)
- Inference serverless FREE: models ≤ ~70B, shared GPU + queue.
- Spaces FREE: CPU or T4 16 GB → model must be < ~14 GB on disk.
- Full weights of GLM-5.2 (753 GB) / Kimi-K2.6 (1,058 GB) need PAID H100/A100.
- Quantized MoEs are still far above free limits (see §4).

## 4. Quantized GGGUF size estimation (Xet gotcha)
HF repos now use **Xet storage**. A `curl` of the `.gguf` resolve URL returns
only pointer metadata — real shard size is NOT retrievable via curl
(shards report ~9 MB even when GB). So:
- Do NOT trust API `size` field for shards (comes back 0).
- Do NOT try to `curl` shard bytes to measure — you get the pointer, not the blob.
- Estimate from parameter count (deterministic):
  `size_GB ≈ params_B × 1e9 × bits_per_param / 8 / 1e9`
  bits: IQ2_M≈2.2, Q2_K≈2.6, Q3_K_M≈3.5, Q4_K_M≈4.5, Q6_K≈6.0
Estimated sizes (real session, ~355B GLM-5.2 and ~1T Kimi-K2.6):
| Model      | Quant     | Est. size | Fits HF free? |
|------------|-----------|-----------|---------------|
| GLM-5.2    | IQ2_M     | ~98 GB    | (low-RAM)   |
| GLM-5.2    | Q4_K_M    | ~200 GB   |             |
| Kimi-K2.6  | IQ2_M     | ~275 GB   |             |
| Kimi-K2.6  | Q4_K_M    | ~563 GB   |             |
GGUF quant files DO exist (e.g. `unsloth/GLM-5.2-GGUF`, `unsloth/Kimi-K2.6-GGUF`)
— confirm via HF API `siblings` filtered by `Q[2-8]`/`IQ`, but size = param estimate.

## 5. Decision rule
Ollama → open-weight, local, must fit RAM. HF free → small only (≤70B / <14GB).
OpenRouter → any listed model via API key, no hardware limit. For Claude/GPT
(fully proprietary) or giant MoEs, OpenRouter (or the vendor's own paid API) is
the only option; "install locally / HF free" is not possible.
