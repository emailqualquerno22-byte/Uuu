# Model existence on Ollama — verified facts (session 2026-07-13)

## The trap
The Ollama website `/library/<name>` returns HTTP 200 for models that are
NOT published (pre-announcements / stale pages). A 200 does NOT mean the
weights exist. `ollama search` does not exist in current CLI versions.

## Authoritative method
`timeout 8 ollama pull <name>`:
- starts printing `pulling manifest` + downloads → EXISTS
- `Error: pull model manifest: file does not exist` → GHOST (registry 404)

## What the user asked vs. reality
User asked for: glm-5.2, kimi-k2.7, kimi-k2.6.
All three → "file does not exist" (GHOST). Despite having /library pages.

## What actually exists (tested same session)
- `glm-4.7-flash` → EXISTS (began downloading 19 GB). Too big for <5 GB RAM.
- `kimi-k2` (plain) → GHOST.
- `glm-4.7` (plain) → GHOST.
- `qwen2.5:3b` (1.9 GB) → EXISTS, runs fine on CPU-only 2-core / 3.6 GB free.
- `qwen2.5:7b` (4.7 GB) → EXISTS but OOM-killed on load under ~5 GB free RAM.

## Takeaway
When a user names a specific model version (esp. "latest big number" like
GLM 5.2 / Kimi 2.7), do NOT trust the website. Run the `ollama pull` probe
and report the real publish state before promising to install it.
