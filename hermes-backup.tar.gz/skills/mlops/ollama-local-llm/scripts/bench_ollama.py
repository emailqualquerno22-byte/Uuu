#!/usr/bin/env python3
"""Benchmark TTFT + throughput of an Ollama model via the streaming API.

Usage: python3 bench_ollama.py <model> ["prompt"]
Measures:
  - TTFT: time from request to first token (cold load ~19s, warm ~2s on CPU)
  - Throughput: tokens/sec generated
  - Total time + a short print of the response.
"""
import json, time, urllib.request, sys

URL = "http://127.0.0.1:11434/api/generate"
MODEL = sys.argv[1] if len(sys.argv) > 1 else "qwen2.5:3b"
PROMPT = sys.argv[2] if len(sys.argv) > 2 else "Explique em uma frase o que e inteligencia artificial."

payload = json.dumps({
    "model": MODEL,
    "prompt": PROMPT,
    "stream": True,
    "options": {"temperature": 0},
}).encode()

req = urllib.request.Request(URL, data=payload, headers={"Content-Type": "application/json"})
t0 = time.time()
first_tok = None
n_tok = 0
text = []
with urllib.request.urlopen(req) as resp:
    for line in resp:
        line = line.strip()
        if not line:
            continue
        obj = json.loads(line)
        if first_tok is None and obj.get("response"):
            first_tok = time.time()
        if obj.get("response"):
            text.append(obj["response"])
            n_tok += 1
        if obj.get("done"):
            final = obj
t_end = time.time()

ttft = (first_tok - t0) if first_tok else None
gen_time = (t_end - first_tok) if first_tok else 0
tps = n_tok / gen_time if gen_time > 0 else 0

print(f"Modelo: {MODEL}")
print(f"Prompt tokens (est.): {final.get('prompt_eval_count')}")
print(f"TTFT (tempo ate 1o token): {ttft*1000:.0f} ms" if ttft else "TTFT: n/a")
print(f"Tokens gerados: {n_tok}")
print(f"Throughput: {tps:.1f} tok/s")
print(f"Tempo total: {t_end - t0:.1f} s")
print("-" * 40)
print("Resposta:", "".join(text)[:400])
