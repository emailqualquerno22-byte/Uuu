#!/usr/bin/env bash
# Verify whether an Ollama model name is actually published on the registry.
# Usage: verify_model_exists.sh <model-name>
# Exits 0 if it starts downloading (exists), 1 if "file does not exist" (ghost).
set -u
NAME="${1:?Usage: $0 <model-name>}"
out=$(timeout 8 ollama pull "$NAME" 2>&1)
if echo "$out" | grep -q "file does not exist"; then
  echo "GHOST: $NAME is NOT published on Ollama (registry 404)."
  exit 1
fi
if echo "$out" | grep -q "pulling manifest"; then
  echo "EXISTS: $NAME is published on Ollama (download started; aborted by timeout)."
  # abort the now-backgrounded pull if it slipped past timeout
  pkill -f "ollama pull $NAME" 2>/dev/null || true
  exit 0
fi
echo "UNKNOWN: unexpected output:"
echo "$out" | head -5
exit 2
