---
name: ollama-local-llm
description: Install, run, verify, and benchmark Ollama local LLMs (open-weight models like Qwen/Llama/GLM/Kimi). Covers the non-obvious "does this model actually exist on Ollama?" check, CPU-only / low-RAM sizing, and the safe install pattern that avoids the blocked `curl | sh`. Use whenever the user wants to run a model locally via Ollama, test local model speed/responsiveness, or check if a named model is available.
---

# Ollama: install, verify existence, run, benchmark

## When to load
- User asks to "install a model locally", "run X on Ollama", "test model speed locally".
- User names a model (Claude/GPT/Qwen/GLM/Kimi/Llama) and wants it local.
- FIRST clarify: Ollama runs **open-weight only** (Qwen, Llama, Mistral, DeepSeek, Gemma, GLM, Kimi). **Claude (Anthropic) and GPT (OpenAI) are proprietary and NOT installable on Ollama** — they need a paid API key. Offer an open-weight substitute (Qwen2.5 is a strong default) or API-config path instead.

## 1. Safe install (avoid blocked `curl | sh`)
The agent's security scan BLOCKS `curl ... | sh`. Instead:
1. Download the script to a file: `curl -fsSL https://ollama.com/install.sh -o /tmp/ollama_install.sh`
2. Inspect it (read key sections — download/extract paths, systemd block).
3. Run it: `sh /tmp/ollama_install.sh` (runs as root in most containers; script uses sudo only if not root).

## 2. Start the server
systemd is usually NOT running in containers. Do NOT use `nohup ... &` in a foreground terminal call — the agent blocks that (use `terminal(background=true)` instead).
```
terminal(background=true): OLLAMA_HOST=127.0.0.1:11434 ollama serve
```
Health check: `curl -s http://127.0.0.1:11434/api/version` → `{"version":"..."}`.

## 3. CRITICAL: verify a model ACTUALLY exists before promising it
This is the single most non-obvious part. The Ollama website is misleading:
- `ollama search <q>` does NOT exist in current versions (unknown command).
- `https://ollama.com/library/<name>` returns HTTP 200 for models that are NOT published (pre-announcements / stale pages) — a 200 does NOT mean the weights exist.
- `ollama list` only shows already-downloaded models.

### Authoritative check (use this):
```
timeout 8 ollama pull <name> 2>&1 | head -3
```
- Exists → prints `pulling manifest` then starts downloading blobs.
- Does NOT exist → `Error: pull model manifest: file does not exist` (registry 404).

Real example from a session: user asked for `glm-5.2`, `kimi-k2.6`, `kimi-k2.7-code` — all returned "file does not exist" despite having `/library/...` pages. Actual published models were `glm-4.7-flash` (19 GB) etc. See `references/model_existence.md`.

If you must probe the registry HTTP directly (not recommended — rate-limited / version-fragile):
`curl -s -o /dev/null -w "%{http_code}" "https://registry.ollama.ai/v2/library/<name>/manifests/latest"` → 200 = exists, 404 = ghost.

Refinement — probe a **specific tag** (not just `latest`) to confirm the quant/tag is real AND see it exists:
`curl -sI "https://registry.ollama.ai/v2/library/<name>/manifests/<tag>"` → `HTTP/2 200` with an `ollama-content-digest:` header = tag exists. Verified in-session: `gemma3` tags `1b`, `4b`, `12b` all returned 200; this is how we confirmed the Gemma 3 family before pulling.

NOTE: the Ollama **web** JSON API has churned — `https://ollama.com/api/search` and `https://ollama.com/api/library/<name>` now return `{"error":"path ... not found"}` (HTTP 404). Don't rely on those; the registry v2 manifest probe above is the authoritative existence check. (The older `https://ollama.com/library/<name>` HTML page may still 200 for ghost models — see the `ollama search` caveat above.)

## 4. CPU-only / low-RAM sizing (real measured heuristic)
Measured on a 2-core CPU, ~3.6 GB free RAM, no GPU, no swap:
- **7B model (Qwen2.5 7B, ~4.7 GB):** OOM-killed on load — `llama-server process has terminated: signal: terminated` in server log. Too big for <5 GB free.
- **3B model (Qwen2.5 3B, ~1.9 GB):** works well.
  - TTFT first call (cold load): ~19 s. Subsequent (warm): ~2 s.
  - Throughput: ~7–8 tok/s. Responsive enough for interactive use.
  - **Gemma 3 1B (Q4, ~815 MB):** runs comfortably on <5 GB free, fast TTFT; the best default when RAM is tight and the user just wants a small local model working. Verified in-session: `ollama pull gemma3:1b` succeeded (815 MB download) and `ollama run gemma3:1b` answered in Portuguese. Gemma 3 family on Ollama = tags `1b`, `4b`, `12b`, `27b`. (Gemma 4 ALSO exists now — see §9 — but its smallest tag is ~7 GB, too big for <5 GB free; Gemma 3 1B stays the local-fit default.)
  - To run 7B+ you need +~4 GB RAM or a swap file. Create swap if user wants bigger models:
  `sudo fallocate -l 20G /swapfile && sudo chmod 600 /swapfile && sudo mkswap /swapfile && sudo swapon /swapfile`

## 5. Benchmark speed/responsiveness
Use the streaming `/api/generate` endpoint and measure TTFT (time to first token) + throughput. Reusable script: `scripts/bench_ollama.py`. Run `python3 bench_ollama.py <model> "<prompt>"`.
Sample output: `TTFT`, `Tokens gerados`, `Throughput`, `Resposta:`.

## 6. Pitfalls
- **`nohup ... &` / `setsid` in a foreground `terminal()` call is blocked.** Use `terminal(background=true)`.
- **`pkill -f "ollama pull"` can kill the agent's own shell** (exit -15) if the pattern matches the wrapping command. Prefer `timeout` to bound pulls, or kill by exact PID from `process(action='list')`.
- A Pyright false-positive (`final.get`) on `bench_ollama.py` is harmless — `final` is just a variable name.
- Model download sizes are large (GB). Use `terminal(background=true, notify_on_complete=true)` for `ollama pull` and `process(action='wait')`.

## 6b. DISK FULL while pulling (32 GB cloud boxes are tight)
A 32 GB root fs fills fast: 2 models (qwen2.5:3b 1.9G + qwen2.5:7b 4.7G) + a partial
5–10 GB pull => `no space left on device` mid-download. Session hit this twice.

1. **Check before pulling:** `df -h /` → if `Avail` < model size, free space FIRST.
2. **Free by removing a local model:** `ollama rm <name>` (frees its blobs).
3. **Clean a FAILED/partial pull** — Ollama leaves orphan blobs `ollama rm` does NOT remove,
   in `~/.ollama/models/blobs/`:
   - older layout: `sha256-<hash>-partial`
   - newer layout: `sha256-<hash>-partial-0` .. `-partial-15` (tiny metadata) PLUS one big
     `sha256-<hash>` blob holding the 4–10 GB downloaded so far.
   Recover the GBs: `rm -f ~/.ollama/models/blobs/*partial* ~/.ollama/models/blobs/sha256-<hash>`
   and `rm -rf ~/.ollama/models/manifests/*<model>*`. The `-partial-N` files ALONE are tiny —
   freeing them does NOT recover space; the big `<hash>` blob is what matters.
4. **Capacity plan:** 9.6 GB model (`gemma4`) needs ~10 GB free; 5.5 GB Q4 (`glm4:9b`) needs
   ~6 GB. With 32 GB total and ~11 GB already in `~/.ollama`, you can hold ~2 models — drop one
   before pulling a 3rd. (Sizes are real measured Gemma 3 / GLM-4 quants; do NOT cite "gemma4" —
   that model does not exist on Ollama, the current family is **Gemma 3**.)
5. **digest mismatch on a finished pull** (`Error: digest mismatch, file must be downloaded
   again`): download corrupted (network blip). Model is unusable — `ollama rm` and re-pull;
   and don't try to run it (a partial pull hit this exact error in-session).
- **Ask before deleting a model the user may want** (clarify() with explicit size trade-offs).
  Do NOT silently wipe models.

## 7. When Ollama doesn't carry the model: routing to HF free tier vs OpenRouter cloud
If the user wants a model that isn't on Ollama (proprietary like Claude/GPT, or a giant open MoE like GLM-5.2 / Kimi-2.6 that isn't published as Ollama weights), route before promising anything:

**A. OpenRouter (cloud API — no download, no GPU needed).** Authoritative, no-auth check of availability + pricing + context. The key is NOT always an env var — on Hermes the OpenRouter credential often lives in `~/.hermes/auth.json` under `credential_pool.openrouter[].access_token` (extract with a small python read, never print it). If `OPENROUTER_API_KEY` is unset, grep `auth.json` before concluding "no key". Reality check on limits: the free-models daily quota is 50 req/day (HTTP 429 when exhausted) and the paid tier needs credits — a key with ~0 credits returns HTTP 402 ("can only afford N tokens"). So "key present" ≠ "usable"; test with a 1-token call before promising the user a working cloud model.
```bash
curl -s "https://openrouter.ai/api/v1/models" | python3 -c "
import sys,json
d=json.load(sys.stdin)
for m in d.get('data',[]):
    if any(k in m['id'].lower() for k in ['glm','kimi','<seu-termo>']):
        print(m['id'],'| ctx',m.get('context_length'),'| \$',m.get('pricing',{}).get('prompt'))
"
```
Real session result: `z-ai/glm-5.2`, `moonshotai/kimi-k2.6`, `moonshotai/kimi-k2.7-code` ALL exist on OpenRouter (pricing ~\$0.6–0.9 / 1M input tok). This is the viable path for giant models — you call them via API key, nothing is downloaded. Needs `OPENROUTER_API_KEY`.

**B. HuggingFace free tier — does NOT fit giant MoEs.** Don't promise HF "free cloud" for 355B–1T-param models. Hard limits:
- HF Inference serverless **free**: models **≤ ~70B** only, shared GPU + queue.
- HF Spaces **free**: CPU or T4 16 GB RAM → model must be **< ~14 GB** on disk.
- Even the smallest quantization of a giant MoE is far above this (see estimates in `references/cloud_tier_routing.md`: GLM-5.2 IQ2_M ≈ **98 GB**, Kimi-K2.6 IQ2_M ≈ **275 GB**). A 753 GB / 1 TB full-weight model needs paid H100 clusters.

**C. Estimating quantized GGUF size (when you can't measure it).** HF now uses **Xet storage** — `curl` of a `.gguf` resolve URL returns only the *pointer* metadata, not the blob (shards show ~9 MB via curl even when real size is GB). So you CANNOT measure shard size with curl. Fall back to deterministic param-count estimation:
```
size_GB ≈ params_billions × 1e9 × bits_per_param / 8 / 1e9
bits: IQ2_M≈2.2, Q2_K≈2.6, Q4_K_M≈4.5, Q6_K≈6.0
```
Confirm the GGUF quant files exist via `https://huggingface.co/api/models/<repo>` (filter siblings by `Q[2-8]`/`IQ`), but compute size from params, not from the API `size` field (it comes back 0 for shards).

**Decision rule:** Ollama = open-weight, local, fits your RAM. HF free = small (≤70B / <14GB) only. OpenRouter = any listed model via API key, no hardware limit. See `references/cloud_tier_routing.md`.

## 8. Verify benchmarks & "which OpenAI model is it like?" workflow
Users often ask whether a candidate model is "good" on agentic benchmarks and which proprietary model it rivals. Do this without fabricating:

1. **Pull the model card's own benchmark tables** (authoritative source), not third-party summaries:
   `curl -sL "https://huggingface.co/<author>/<model>/raw/main/README.md" | grep -iE "BFCL|TAU|IFEval|MMLU|SWE|agent|tool|function"`
2. **Agentic benchmarks to look for:** BFCL-v3 (Overall / MultiTurn — function calling), TAU-Bench (Retail / Airline — multi-step agent), SWE-bench (code agent), IFEval (instruction following). These directly indicate tool-use / agent capability.
3. **Compare against the OpenAI row IN THE SAME TABLE.** Good model cards already include `GPT-4o` / `GPT-4o-1120` as a comparison row — use those published numbers rather than fetching external leaderboards (live BFCL/TAU sites often don't resolve from the agent environment).
4. **Be explicit about the "same-family, not same-size" gap.** Model cards frequently publish agentic scores for the *large* variant only (e.g. GLM-4-32B-0414) but the user may be running the *small* variant (GLM-4-9B). State clearly: "the 32B scores X; the 9B is the same family/training but has no published agentic score and will be lower."
5. **Classify by size, then map to OpenAI tier:** ~9B open-weight ≈ GPT-4o-mini class; ~32B open-weight ≈ GPT-4o class (can match/beat on agentic); frontier proprietary (GPT-5.x, Claude Opus) has no open-weight equivalent at 9–32B.
   Verified example (GLM-4-32B-0414 vs GPT-4o-1120, from the official card): IFEval 87.6 vs 81.9, BFCL-v3 Overall 69.6 vs 69.6 (tie), TAU-Bench Retail 68.7 vs 62.8, Airline 51.2 vs 46.0. See `references/benchmark_findings.md`.

## 9. Pitfall: model-name reality check (don't compare to non-existent models)
- **Verify the target model name actually exists before benchmarking against it.** Users request models by rumor: e.g. "GPT-5.1" does not exist (no official announcement). The real OpenAI line now ships as `gpt-5.x` on OpenRouter (`gpt-5.4-nano`, `gpt-5.5`, `gpt-5.6-*`).
- **CORRECTION — "Gemma 4" DOES exist now (this skill previously said it didn't).** As of mid-2026 Gemma 4 is published on Ollama and HF. Real Ollama tags confirmed in-session: `gemma4:latest` (≈9.6 GB), `gemma4:e2b` (≈7.16 GB), `gemma4:e4b` (≈9.61 GB), `gemma4:12b` (≈7.56 GB), `gemma4:26b`, `gemma4:31b`, `gemma4:cloud`. On HF, official GGUFs exist (`google/gemma-4-12B-it-qat-q4_0-gguf` ≈6 GB; `unsloth/gemma-4-26B-A4B-it-qat-GGUF` Q4 ≈14 GB). **None fit a <5 GB-free machine** — smallest is ~6 GB. Also note `gemma4:1b/2b/4b/8b` all 404 (no small Gemma 4 tag). So: Gemma 4 is real, but a constrained-RAM user must fall back to **Gemma 3 1B** locally, or run Gemma 4 via OpenRouter cloud (`google/gemma-4-26b-a4b-it:free` / `:gemma-4-31b-it:free` exist, but hit the free daily limit — see §7A).
- **GLM-5.2 also exists** (the skill's earlier draft implied it might not). On OpenRouter it's `z-ai/glm-5.2` (ctx 1,048,576, ~$0.0000006/tok, verified available). As HF GGUF: `unsloth/GLM-5.2-GGUF` — but its smallest quant (UD-IQ2_XXS) is ~238 GB (a giant MoE), so it CANNOT run locally on normal hardware; cloud API is the only viable route. `glm4:9b` (5.46 GB) remains the local-fit GLM on Ollama.
- If asked "does X approach GPT-5.1?": state the name isn't real, then anchor the comparison to the closest *real* tier (GPT-4o if the open model is ~32B; GPT-4o-mini if ~9B) or to an actual GPT-5.x if the user wants frontier.
- **Proprietary ≠ open, ever.** Claude/GPT are never on Ollama or HF-free; only via paid API (OpenRouter or vendor). Don't let a user's phrasing ("install Claude locally") pass without the correction.
- A model card's own comparison table is the ground truth for "which OpenAI model is it like" — trust it over memory or vibes.

## References
- `references/gemma4_glm5_existence_2026.md` — verified Gemma 4 Ollama/HF tags + sizes, GLM-5.2 (238 GB GGUF, cloud-only), OpenRouter key-in-auth.json + 429/402 limit behavior.
- `references/cloud_tier_routing.md` — HF free-tier limits, Xet gotcha, param-count size estimation, OpenRouter availability findings.
- `references/benchmark_findings.md` — verified agentic benchmark numbers (GLM-4 family vs GPT-4o) and the size→tier mapping used for "which OpenAI model is it like".
- `scripts/bench_ollama.py` — TTFT/throughput benchmark, streaming API.
- `scripts/verify_model_exists.sh` — quick check whether a model name is published on the registry.
