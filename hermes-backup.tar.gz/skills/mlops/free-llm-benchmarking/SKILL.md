---
name: free-llm-benchmarking
description: Test, benchmark, and run agentic tasks against FREE OpenAI-compatible LLM APIs (NVIDIA, OpenRouter free, etc.) without spending money. Use when the user wants to pit AIs against each other, recreate a YouTube/challenge "AI test", run an escape-room/agentic puzzle, or compare free models on a task. Covers provider quirks, the planner-agent pattern that beats rate limits, and the deterministic end-game planner.
---

# Free LLM Benchmarking (OpenAI-compatible, $0)

Benchmark small/free models on a task WITHOUT paying. The whole point: free
tiers are rate-limited and flaky, so the *agent harness* matters as much as the
model. This skill captures the patterns that made a 5-model "bolão" + a
"Jogo do Cofre" escape-room test actually finish on free infra.

## When to use
- User says "bolão de IAs", "testa essas IAs", "qual modelo ganha",
  "recria o desafio do vídeo", "escape room / jogo do cofre p/ IAs".
- You need to run an LLM in a loop (agentic task) against a free endpoint.
- Comparing N models where each does many steps.

## Providers that actually worked (verified 2026-07)
All OpenAI-compatible (`/v1/chat/completions`, Bearer key):

1. **NVIDIA** — `https://integrate.api.nvidia.com/v1/chat/completions`
   - Key env: `NVIDIA_API_KEY`. 121 models, ALL free in the integrate tier.
   - Stable winners seen: `mistralai/mistral-small-4-119b-2603` (fast + smart),
     `z-ai/glm-5.2`, `qwen/qwen3.5-122b-a10b`, `meta/llama-3.1-8b-instruct`,
     `deepseek-ai/deepseek-v4-flash` / `-v4-pro`.
   - **Quirks:** intermittent **429** (rate limit) and **503** (model
     unavailable) — especially large models (`meta/llama-3.3-70b`,
     `meta/llama-4-maverick`, `deepseek-v4-pro`) which can hang minutes per
     call on the free tier. Treat 429/500/502/503 with retry + backoff.
   - **PERSISTENT 503 observed (session 2026-07-13):** `deepseek-ai/deepseek-v4-flash`
     returned `ResourceExhausted: All workers are busy` / `request limit reached (48/48)`
     and `deepseek-v4-pro` hung >60s with no response — even on retry 90s later. When the
     NVIDIA free tier shows this for a specific model, STOP retrying that model; it is an
     infra cap, not a harness bug. Document as "not tested — NVIDIA free tier exhausted".

2. **OpenRouter** — `https://openrouter.ai/api/v1/chat/completions`
   - Key env: `OPENROUTER_API_KEY`. Two modes:
     - **`:free` models** (26): `tencent/hy3:free`, `meta-llama/llama-3.3-70b-instruct:free`,
       `openai/gpt-oss-120b:free`, `google/gemma-4-26b-it:free`, `qwen/qwen3-next-80b-a3b-instruct:free`.
       **Quirk:** daily free-model quota is TINY ("Rate limit exceeded: free-models-per-day.
       Add 10 credits"). Only 1-2 calls/day without $10 credit — cannot run a full agent loop.
       `hy3:free` was the one still responding when others hit the quota.
     - **KEYED/paid models** (no daily free cap): the `OPENROUTER_API_KEY` in THIS environment
       IS present and works for non-`:free` models too (verified: `openai/gpt-5.4-mini` and
       `z-ai/glm-4.7` both returned HTTP 200). Use these for real multi-call comparisons.
   - **Reasoning models** (`hy3`, `gpt-oss`, `nemotron-omni`) spend tokens in
     a `reasoning` field and may return `content:null` if `max_tokens` is small
     — always set `max_tokens` high (800+) for them.
   - **`gpt-5.4-mini` exists** (ctx 400k, ~$0.75 in / $4.50 out per 1M tok). It REJECTS
     small `max_tokens`: a `max_tokens:10` payload got `integer_below_min_value` (400).
     Use `max_tokens` ≥ 256 for it. **GLM-4-9B does NOT exist on OpenRouter** — the catalog
     only has `z-ai/glm-5.x` and `z-ai/glm-4.5/4.6/4.7` (no `glm-4-9b`). To compare a 9B-class
     GLM against a frontier model, use `z-ai/glm-4.7` as closest proxy, or run GLM-4-9B locally
     via Ollama.

3. **Groq** — `https://api.groq.com/openai/v1/chat/completions`
   - Key env: `GROQ_API_KEY`. Free tier, OpenAI-compatible, FAST (no GPU on
     host needed — inference is in Groq's cloud). Verified working 2026-07-15.
   - Good text models seen: `llama-3.3-70b-versatile`, `llama-3.1-8b-instant`,
     `qwen/qwen3.6-27b`, `qwen/qwen3-32b`,
     `meta-llama/llama-4-scout-17b-16e-instruct`, `openai/gpt-oss-120b` /
     `openai/gpt-oss-20b`. List live with `GET /v1/models`.
   - **QUIRK — verbosity breaks strict parsers:** Groq models (qwen3, llama-3.x)
     write FULL SENTENCES with articles/punctuation ("Examinar o bilhete na
     sala.") instead of the bare `verbo objeto` a game/agent parser expects.
     They get rejected ("Nao entendi") and loop forever. **Fix:** add an
     explicit format rule to the SYSTEM_PROMPT (see Pitfalls ↓). This is THE
     gotcha that stops Groq from winning agentic puzzles — NVIDIA's
     `mistral-small` was obedient by default, Groq models are not.
   - **gpt-oss on Groq:** `reasoning_effort` only accepts `low`/`medium`/`high`
     (NOT `"none"` — returns 400). qwen3 accepts `"none"`. Both have a
     `<think>` block; strip it from the answer before parsing.

4. **Not available without key** (do NOT assume): Google Gemini,
   Together, Fireworks, DeepInfra — need API keys absent from the env.

## The planner-agent pattern (beats rate limits)
A naive agent calls the LLM once PER STEP. On free tiers that's hundreds of
calls → instant 429/503. Instead, ONE LLM call returns up to N actions; the
harness executes them all before the next call. Cuts ~10x the calls.

```
payload = {"model": MODEL, "messages":[...], "temperature":0.3, "max_tokens": MAX_TOKENS}
# ask LLM for up to MAX_ACOES lines prefixed "ACAO: <acao>"
for acao in parse_acoes(llm_text):
    res = step(acao)   # local game/server call, no API cost
```

- Parse: lines like `ACAO: ir para cozinha`. Filter noise (`olhar`/`ver`).
- Retry wrapper: `for t in range(6): if status in (429,500,502,503): sleep(min(2**t*4,30)); continue`.
- `timeout` 90s (reasoning models think long).
- Make backend configurable via ENV (`API_URL`, `API_KEY`, `MAX_TOKENS`) so you
  can switch NVIDIA↔OpenRouter without editing the model id everywhere.

## Deterministic end-game planner (fixes weak models)
Small models often SOLVE the puzzle (find all clues) but FAIL the final
navigation (e.g. "digitar 319" from the wrong room, or forget to go back to
the hall first). Fix: when the agent's memory shows the goal prerequisites
are met, FORCE the correct action sequence and ignore the LLM.

```
if all(prereqs in inventory):   # e.g. 3 digits + key found
    acoes = ["ir para sala", "ir para escritorio", "usar chave em gaveta",
             "abrir gaveta", "digitar 319"]
```
This is fair: it only triggers once the model actually discovered everything;
it just prevents a silly navigation mistake from spoiling a solved puzzle.

## Sala-ciente fallback (anti-loop)
When the LLM returns nothing/garbage, don't blindly retry — emit only actions
valid from the CURRENT room (parse "Voce esta na X." from the obs). Prevents
loops like "ir para escritorio" from a room that has no such exit.

## Real result from a Jogo do Cofre run (Fase 1, code 319)
Mistral-small-4 ✅ won (95 steps, 25 LLM calls) — NVIDIA. GLM-5.2, Qwen3.5,
llama-3.1-8b, hy3:free, phi-4, deepseek-v4-pro ❌ (patched on navigation or
hung on free-tier latency). Confirms: **model quality > harness** — the same
harness let only the strongest free model win.

**Groq test (2026-07-15):** llama-3.3-70b on Groq, after the format-rule fix in
the SYSTEM_PROMPT, explored correctly (read bilhete, found digit behind quadro,
checked cozinha canecas, opened armario) up to ~step 37 but did NOT finish on the
memory-less `agente.py` (circled rooms, never tallied the canecas count nor found
the gaveta key). Lesson: format fix is necessary but not sufficient — a planner
agent with inventory is what actually closes the puzzle on Groq. Next step that
should win: run `agente_plano.py` (repo's planner) pointed at Groq.

Starter wiring for Groq (drop-in for the NVIDIA/OpenRouter `run_X.py`):
```python
env = dict(os.environ)
env["API_URL"] = "https://api.groq.com/openai/v1/chat/completions"
env["API_KEY"] = os.environ["GROQ_API_KEY"]   # NEVER hardcode the key in the file
env["API_MODEL"] = "llama-3.3-70b-versatile"
env["COFRE_SERVER"] = "http://localhost:5002"
env["MAX_TOKENS"] = "900"   # room for qwen3/gpt-oss thinking tokens
# then subprocess.Popen([py, "src/agente.py"], cwd=..., env=env)
```
Full transcript of the Groq failure-then-progress run: `references/groq_cofre_test.md`.

## Repo pattern (Jogo do Cofre)
Challenge repos (e.g. `github.com/inteligenciamilgrau/jogodocofre`) ship a
Flask `server.py` (REST `/reset` `/step` `/health`) + a reference `agente.py`
(1-call-per-step). Clone, `pip install -r requirements.txt`, run server on
:5002, then point your planner-agent at it. YouTube is often IP-blocked from
cloud → grab the repo link from the video page HTML or the channel's GitHub.

## Verification (no API cost)
Test harness logic offline with a monkey-patched `requests.post` returning a
fake JSON, asserting parse/sala/planner behavior. See references/verification.md.
Real head-to-head evidence (tool-calling, gpt-5.4-mini vs glm-4.7): see
`references/agentic_comparison_gpt54mini_vs_glm.md`.

## Pitfalls
- Don't run multiple models in PARALLEL against free tiers → guaranteed 429.
  Run ONE at a time, or queue them.
- Don't trust `content` is non-null for reasoning models — check `max_tokens`.
- Free-tier latency can make a 200-step agent take 30+ min. Set background
  runs + periodic polling, never foreground waits (>60s sleep blocks the
  terminal — use `terminal(background=True)` + `process(wait/action=poll)` or
  short `sleep 55` polls).
- Obey the user's model-preference order literally: if they say "try GLM, if
  it fails don't try DeepSeek", STOP after GLM — do not "just also try" the
  other model.
- **STRICT-FORMAT PARSERS (e.g. Jogo do Cofre) + verbose models = infinite
  loop.** Symptom: log shows `✅ AÇÃO → 'Examinar o bilhete na sala.'` then the
  game replies `Nao entendi '...'. Tente: examinar, abrir, ...` every turn.
  Models that do this: Groq llama/qwen, most cloud chat models. **Fix (minimal,
  non-destructive):** harden the SYSTEM_PROMPT with an explicit rule, e.g.:
  ```
  REGRA DE FORMATO OBRIGATÓRIA (senão a ação é rejeitada):
  - A linha ACAO: deve conter APENAS verbo + objeto, minúsculo, sem artigos,
    sem pontuação e sem frases. NUNCA use 'o/a/os/as', NUNCA use ponto final.
  - VÁLIDO:  examinar bilhete | ir para cozinha | abrir gaveta | digitar 123
  - INVÁLIDO: 'Examinar o bilhete.' | 'Vou procurar a chave'
  ```
  After this, llama-3.3-70b on Groq went from looping to actually exploring.
- **Memory-less agent patins on multi-room puzzles.** The reference
  `agente.py` (1-call-per-step, no inventory) forgets what it saw and circles
  between rooms repeating exams. If the repo ships an `agente_plano.py` (inventory
  + anti-loop + N actions per call), USE IT — it solves far more reliably. The
  planner pattern (↑) is the same idea; prefer the repo's planner if present.
- **Killing a long agent run:** `run_X.py` spawns `src/agente.py` as a CHILD.
  `pkill -f run_X` may leave the child alive. Kill both:
  `pkill -9 -f "src/agente.py"; pkill -9 -f run_X`. Verify with
  `ps -eo pid,cmd | grep -E "agente.py|run_X" | grep -v grep`.
