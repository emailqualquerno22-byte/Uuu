# Agentic comparison: gpt-5.4-mini vs GLM (OpenRouter, 2026-07-13)

Real head-to-head run via OpenRouter `OPENROUTER_API_KEY` (present in this env).

## Test
Same tool-calling prompt against both: "Qual a previsao para Sao Paulo?" with a
`get_weather(city)` function exposed via `tools` + `tool_choice:"auto"`.

| Model | tool_call correct? | city | time |
|---|---|---|---|
| `openai/gpt-5.4-mini` | ✅ | São Paulo | **0.63s** |
| `z-ai/glm-4.7` (proxy for GLM-4-9B) | ✅ | São Paulo | 5.25s |

## Findings
- Both produced a correct structured tool call (same answer). No quality gap on this task.
- `gpt-5.4-mini` ~8x faster (0.63s vs 5.25s) on this endpoint.
- **GLM-4-9B does NOT exist on OpenRouter** (catalog only has glm-5.x and glm-4.5/4.6/4.7).
  Used `glm-4.7` as the closest available GLM proxy. For a true GLM-4-9B comparison,
  run it locally via Ollama (see ollama-local-llm skill).

## Notes
- `gpt-5.4-mini` rejects `max_tokens < ~256` (400 `integer_below_min_value`). Use ≥256.
- GLM-4.7 returned `reasoning_tokens: 104` in usage — it thinks before answering; that
  explains the slower wall-clock despite similar correctness.
