#!/usr/bin/env python3
"""Merge broken/intermediate benchmark results into a main results.json.

Usage:
  python3 consolidate.py results.json results_extra.json [more_extra.json ...]

For every framework in the extra files whose payload is ok=True, it overrides
the same-named entry in the main file (only if the main entry is missing or
ok=False). Then it asserts ALL frameworks end up ok=True and writes back the
main file. Run this after split runs (e.g. run_bench.py then run_extra.py) so
a stale broken entry doesn't poison the report.

No API calls. Offline JSON merge only.
"""
import sys, json

def main():
    if len(sys.argv) < 3:
        print("usage: consolidate.py <main.json> <extra1.json> [extra2.json ...]")
        sys.exit(2)
    main_path = sys.argv[1]
    extra_paths = sys.argv[2:]

    with open(main_path) as f:
        main = json.load(f)

    for ep in extra_paths:
        with open(ep) as f:
            extra = json.load(f)
        for name, payload in extra.items():
            if not isinstance(payload, dict):
                continue
            good = payload.get("ok") is True
            if not good:
                continue
            cur = main.get(name)
            if cur is None or cur.get("ok") is not True:
                main[name] = payload
                print(f"  merged {name} from {ep} (ok=True)")
            else:
                print(f"  {name} already ok in main; left as-is")

    with open(main_path, "w") as f:
        json.dump(main, f, ensure_ascii=False, indent=2)

    all_ok = all(v.get("ok") is True for v in main.values() if isinstance(v, dict))
    print(f"\nTodos ok: {all_ok}")
    if not all_ok:
        print("AVISO: ainda ha frameworks com ok!=True:")
        for n, v in main.items():
            if isinstance(v, dict) and v.get("ok") is not True:
                print(f"  - {n}: ok={v.get('ok')}")
        sys.exit(1)
    print(f"Salvo em {main_path}")

if __name__ == "__main__":
    main()
