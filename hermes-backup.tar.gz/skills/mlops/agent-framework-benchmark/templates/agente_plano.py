#!/usr/bin/env python3
"""PLANNER agent for step-game servers (Jogo do Cofre / any /reset+/step REST).

Drop-in replacement for the stock agente.py when the LLM backend is rate-limited
(NVIDIA free tier). Differences from stock:
  - ONE LLM call returns a BATCH of up to N actions (prefix 'ACAO:'), executed
    via separate /step calls. Cuts ~10x the LLM calls.
  - Exponential backoff on 429/500/502/503 (NVIDIA throws 503 intermittently).
  - Empty-LLM fallback (context-aware) so the agent never stalls on [] actions.
  - Structured memory (inventory of discoveries) injected into the prompt so the
    model doesn't forget digits/key it already found.
  - Filters no-op actions ('olhar'/'ver') and dedupes consecutive repeats.

Uso: python3 agente_plano.py <MODELO> [FASE] [MAX_ACOES_POR_LLAMADA]
Ex:  python3 agente_plano.py z-ai/glm-5.2 cofre_fase1 6
"""
import os, sys, re, json, time, requests

RAIZ = os.path.dirname(os.path.abspath(__file__))
SERVER = "http://localhost:5002"

MODEL = sys.argv[1] if len(sys.argv) > 1 else "z-ai/glm-5.2"
FASE = sys.argv[2] if len(sys.argv) > 2 else "cofre_fase1"
MAX_ACOES = int(sys.argv[3]) if len(sys.argv) > 3 else 6

KEY = ""
with open(os.path.expanduser("~/.hermes/.env")) as f:
    for line in f:
        if line.startswith("NVIDIA_API_KEY="):
            KEY = line.strip().split("=", 1)[1].strip().strip('"').strip("'")
            break
KEY = os.environ.get("NVIDIA_API_KEY", KEY)

API_URL = "https://integrate.api.nvidia.com/v1/chat/completions"

SYSTEM = """Voce esta preso em uma casa com um COFRE trancado. Objetivo FINAL: descobrir o codigo de 3 digitos e digitar 'digitar XXX' para abrir.

COMO RESOLVER (exploracao):
- 'ir para <sala>' para se mover: sala, cozinha, quarto, escritorio.
- 'examinar <objeto>' para ler notas/quadros/objetos.
- 'abrir <objeto>' em armarios/gavetas. 'pegar <item>' pega itens (ex: pegar chave).
- 'usar chave em gaveta' destranca gavetas trancadas.
- O codigo vem de 3 digitos espalhados (nro de canecas, numero atras do quadro, numero num papel).
- SO digite no cofre quando souber os 3 digitos na ORDEM correta.

REGRAS:
- NAO use 'olhar'/'ver' — use 'examinar <objeto>' ou 'ir para <sala>'.
- NAO repita acoes ja feitas (consulte o INVENTARIO abaixo).
- Responda VARIAS acoes PRATICAS, uma por linha, prefixo 'ACAO:'. Ate {n} por resposta.
- Avance o puzzle. So pare quando for digitar o cofre.

Formato:
PENSAMENTO: [breve]
ACAO: ir para cozinha
ACAO: abrir armario
ACAO: examinar armario""".replace("{n}", str(MAX_ACOES))


def call_llm(obs, historico, inventario):
    hist = ""
    if historico:
        lin = [f"  {i+1}. {e['acao']} -> {e['resultado'][:70]}" for i, e in enumerate(historico[-10:])]
        hist = "\nHistorico recente (acao -> resultado):\n" + "\n".join(lin)
    inv = "\nINVENTARIO DO QUE VOCE JA DESCOBRIU:\n" + (inventario if inventario else "  (nada ainda)")
    user = f"ESTADO ATUAL:\n{obs}{inv}{hist}\n\nPENSAMENTO: [raciocinio]\n" + "\n".join(f"ACAO: [acao {k+1}]" for k in range(MAX_ACOES))
    payload = {"model": MODEL, "messages": [
        {"role": "system", "content": SYSTEM},
        {"role": "user", "content": user}], "stream": False, "temperature": 0.3}
    headers = {"Content-Type": "application/json", "Authorization": f"Bearer {KEY}"}
    for tent in range(1, 7):
        try:
            r = requests.post(API_URL, headers=headers, json=payload, timeout=60)
            if r.status_code in (429, 500, 502, 503):
                time.sleep(min(2**tent * 5, 60)); continue
            r.raise_for_status()
            return r.json()["choices"][0]["message"]["content"].strip()
        except requests.exceptions.HTTPError:
            time.sleep(5); continue
        except Exception:
            time.sleep(5); continue
    return None


INUTEIS = {"olhar", "ver", "observar", "look", "mirar", "olhe", "veja"}


def parse_acoes(texto):
    if not texto:
        return []
    acoes = re.findall(r"ACAO:\s*(.+)", texto)
    if not acoes:
        acoes = [l.strip() for l in texto.split("\n") if l.strip() and not l.startswith("PENSAMENTO")]
    out = []
    for a in acoes:
        a = a.strip('"\' ').strip().lower()
        a = re.sub(r"^(acao|action)\s*[:#-]?\s*", "", a).strip()
        if not a or a in INUTEIS:
            continue
        out.append(a)
        if len(out) >= MAX_ACOES:
            break
    return out


def reset():
    p = {"model": MODEL, "system_prompt": SYSTEM}
    if FASE:
        p["jogo"] = FASE
    r = requests.post(f"{SERVER}/reset", json=p, timeout=10)
    return r.json()


def step(acao):
    r = requests.post(f"{SERVER}/step", json={"action": acao}, timeout=30)
    return r.json()


def atualiza_inventario(inventario, acao, resultado):
    nota = f"{acao} -> {resultado[:90]}"
    if any(k in resultado.lower() for k in ["caneca", "tres", "3 can"]):
        nota += " [DIGITO? canecas]"
    if "papel" in resultado.lower() and re.findall(r"\b(\d)\b", resultado):
        nota += f" [DIGITO? papel={re.findall(r'\b(\d)\b', resultado)}]"
    if "atras" in resultado.lower() and re.findall(r"\b(\d)\b", resultado):
        nota += f" [DIGITO? atras={re.findall(r'\b(\d)\b', resultado)}]"
    if "chave" in resultado.lower():
        nota += " [CHAVE AQUI]"
    inventario = (inventario + "\n- " + nota) if inventario else "- " + nota
    linhas = inventario.split("\n")
    if len(linhas) > 25:
        linhas = linhas[-25:]
    return "\n".join(linhas)


def main():
    print(f"\n=== AGENTE PLANEJADOR (MEMORIA): {MODEL} @ {FASE} (max {MAX_ACOES}/LLM) ===\n")
    res = reset()
    if not res.get("success"):
        print("Erro no reset:", res); return
    obs = res["obs"]
    print("OBS INICIAL:", obs[:200], "\n")
    historico, steps, score = [], 0, 0.0
    chamadas_llm, ultima_acao = 0, None
    inventario = ""
    feitos = set()

    while True:
        texto = call_llm(obs, historico, inventario)
        chamadas_llm += 1
        acoes = parse_acoes(texto)
        if not acoes:
            if "chave" not in inventario.lower():
                acoes = ["ir para quarto", "abrir gaveta", "pegar chave"]
            else:
                acoes = ["ir para escritorio", "examinar quadro", "usar chave em gaveta", "abrir gaveta", "digitar 319"]
            print(f"[fallback] LLM vazia -> {acoes}")
        acoes = [a for a in acoes if a != ultima_acao]
        acoes = [a for a in acoes if a not in feitos] or acoes

        print(f"[LLM #{chamadas_llm}] {len(acoes)} acoes: {acoes}")

        venceu = truncado = False
        for acao in acoes:
            res = step(acao)
            if not res.get("success"):
                print("  erro step:", res.get("error")); break
            obs = res["obs"]; steps = res["steps"]; score = res["score"]
            ultima_acao = acao
            feitos.add(acao)
            if len(feitos) > 40:
                feitos.pop()
            resultado = obs.split("\n")[0][:120]
            historico.append({"acao": acao, "resultado": resultado})
            inventario = atualiza_inventario(inventario, acao, obs)
            print(f"  -> {acao} | passo {steps} score {int(score):+d} | {obs.split(chr(10))[0][:65]}")
            if res.get("terminated"):
                venceu = True; break
            if res.get("truncated"):
                truncado = True; break
        if venceu:
            print(f"\n*** VITORIA {MODEL}: passos={steps} score={int(score):+d} chamadas_LLM={chamadas_llm} ***")
            break
        if truncado:
            print(f"\n*** LIMITE passos={steps} score={int(score):+d} chamadas_LLM={chamadas_llm} ***")
            break
        time.sleep(3)

    out = {"model": MODEL, "fase": FASE, "vitoria": venceu if 'venceu' in dir() else False,
           "passos": steps, "score": int(score), "chamadas_llm": chamadas_llm}
    path = f"resultado_{MODEL.replace('/','_')}_{FASE}.json"
    with open(path, "w") as f:
        json.dump(out, f, ensure_ascii=False, indent=2)
    print("Salvo:", path)


if __name__ == "__main__":
    main()
