#!/usr/bin/env python3
"""Bolao das IAs - model comparison on the NVIDIA free API (OpenAI-compatible).

Compares MODELS (not frameworks) on ONE shared task, hitting
/v1/chat/completions directly with urllib -- no per-model SDK needed.
Score = acertos/3 * 10 against deterministic ground truth.

Usage: adjust MODELS / TASK / CORRETOS, then: python3 bolao.py
Writes bolao_resultados.json INCREMENTALLY (survives a single model hang).
"""
import os, sys, json, time, datetime, signal, urllib.request

# --- key from ~/.hermes/.env (never shell-cat a token into a URL) ---
with open("/home/codespace/.hermes/.env") as f:
    for line in f:
        if line.startswith("NVIDIA_API_KEY="):
            os.environ["NVIDIA_API_KEY"] = line.strip().split("=", 1)[1].strip().strip('"').strip("'")
            break

BASE = "https://integrate.api.nvidia.com/v1"

# Free NVIDIA models (re-list via GET /v1/models before trusting these)
MODELS = [
    "z-ai/glm-5.2",
    "deepseek-ai/deepseek-v4-flash",
    "deepseek-ai/deepseek-v4-pro",
    "meta/llama-3.1-8b-instruct",
    "qwen/qwen3.5-122b-a10b",
    "mistralai/mistral-small-4-119b-2603",
    # "moonshotai/kimi-k2.6",  # 404 at infra level
    # "nvidia/llama-3.1-nemotron-nano-8b-v1",  # 90s timeout at infra level
]

HOJE = datetime.date.today().isoformat()
TASK = """Voce e um agente de IA. Execute a tarefa abaixo usando raciocinio passo a passo.

TAREFA:
1. Quantos dias faltam para o Natal (25/12/2026) a partir de hoje?
2. Qual e a capital da Franca?
3. Conte quantas vogais (a,e,i,o,u) existem na palavra "agentic".

Responda APENAS com um objeto JSON valido no formato:
{"dias_para_natal": <int>, "capital_franca": "<str>", "vogais_agentic": <int>, "passos": ["<str>", ...]}

Hoje e {hoje}. Nao inclua texto fora do JSON."""
PROMPT = TASK.replace("{hoje}", HOJE)

CORRETOS = {"dias": 165, "capital": "Paris", "vogais": 3}


def call_model(model, timeout=120):
    body = {"model": model, "messages": [{"role": "user", "content": PROMPT}],
            "temperature": 0, "max_tokens": 800}
    if "glm" in model:
        body["response_format"] = {"type": "json_object"}
    data = json.dumps(body).encode()
    req = urllib.request.Request(
        f"{BASE}/chat/completions", data=data,
        headers={"Authorization": f"Bearer {os.environ['NVIDIA_API_KEY']}",
                 "Content-Type": "application/json"}, method="POST")
    with urllib.request.urlopen(req, timeout=timeout) as r:
        return json.load(r)["choices"][0]["message"]["content"]


def timeout_guard(fn, seconds=150):
    def handler(signum, frame):
        raise TimeoutError(f"timeout de {seconds}s")
    signal.signal(signal.SIGALRM, handler)
    signal.alarm(seconds)
    try:
        return fn()
    finally:
        signal.alarm(0)


def parse_json(text):
    import re
    if text is None:
        return None, False
    text = text.strip()
    text = re.sub(r"^```(?:json)?\s*", "", text)
    text = re.sub(r"\s*```$", "", text)
    try:
        return json.loads(text), True
    except Exception:
        s, e = text.find("{"), text.rfind("}")
        if s != -1 and e > s:
            try:
                return json.loads(text[s:e + 1]), True
            except Exception:
                return None, False
    return None, False


def score(model):
    t = time.time()
    try:
        raw = timeout_guard(lambda: call_model(model), seconds=150)
    except Exception as e:
        return {"model": model, "ok": False, "status": "erro_api",
                "erro": str(e)[:200], "nota": 0.0, "acertos": 0}
    dt = round(time.time() - t, 1)
    data, parsed = parse_json(raw)
    data = data or {}
    res = {"model": model, "ok": parsed, "tempo_s": dt, "raw": raw[:600]}
    if parsed:
        acertos = 0
        if data.get("dias_para_natal") == CORRETOS["dias"]:
            acertos += 1
        if (data.get("capital_franca") or "").strip().title() == CORRETOS["capital"]:
            acertos += 1
        if data.get("vogais_agentic") == CORRETOS["vogais"]:
            acertos += 1
        res.update({"dias": data.get("dias_para_natal"),
                    "capital": (data.get("capital_franca") or "").strip().title(),
                    "vogais": data.get("vogais_agentic"),
                    "acertos": acertos, "nota": round(acertos / 3 * 10, 1)})
    else:
        res.update({"acertos": 0, "nota": 0.0})
    return res


if __name__ == "__main__":
    results = []
    for m in MODELS:
        print(f"\n=== {m} ===", flush=True)
        r = score(m)
        print(f"  ok={r.get('ok')} nota={r.get('nota')} tempo={r.get('tempo_s')}s "
              f"dias={r.get('dias')} cap={r.get('capital')} vog={r.get('vogais')}", flush=True)
        results.append(r)
        with open("bolao_resultados.json", "w") as f:  # incremental
            json.dump(results, f, ensure_ascii=False, indent=2)
    print("\n\n=== RANKING (por nota) ===")
    for r in sorted(results, key=lambda x: -x.get("nota", 0)):
        print(f"  {r['model']:42s} nota={r.get('nota')}  acertos={r.get('acertos')}/3  "
              f"tempo={r.get('tempo_s')}s")
    print("\nSalvo em bolao_resultados.json")
