#!/usr/bin/env python3
"""Reusable agent-framework benchmark harness (NVIDIA OpenAI-compatible backend).

Copy + modify. Loads NVIDIA key from ~/.hermes/.env in Python (never shell it).
Runs ONE task through every framework, records {ok, output, tempo_s},
with a per-agent timeout guard so a stuck agent can't hang the run.

Usage: python3 harness.py   (writes results.json)
"""
import os, json, time, datetime, traceback, signal

with open("/home/codespace/.hermes/.env") as f:
    for line in f:
        if line.startswith("NVIDIA_API_KEY="):
            os.environ["NVIDIA_API_KEY"] = line.strip().split("=",1)[1].strip().strip('"').strip("'")
            break

NVIDIA_BASE = "https://integrate.api.nvidia.com/v1"
MODEL = "meta/llama-3.1-8b-instruct"

TASK = """Você é um agente de IA. Execute a tarefa e responda APENAS com JSON:
{"dias_para_natal": <int>, "capital_franca": "<str>", "vogais_agentic": <int>, "passos": [str]}
Hoje é {hoje}. Não inclua texto fora do JSON."""
HOJE = datetime.date.today().isoformat()
PROMPT = TASK.replace("{hoje}", HOJE)

RESULTS = {}
def record(name, ok, payload):
    RESULTS[name] = {"ok": ok, "payload": payload}

def timeout_guard(fn, seconds=150):
    def handler(signum, frame): raise TimeoutError(f"timeout {seconds}s")
    signal.signal(signal.SIGALRM, handler); signal.alarm(seconds)
    try: return fn()
    finally: signal.alarm(0)

# --- framework runners: paste the validated wiring from references/wiring.md ---
def run_smolagents():
    from smolagents import ToolCallingAgent, OpenAIServerModel
    model = OpenAIServerModel(model_id=MODEL, api_base=NVIDIA_BASE, api_key=os.environ["NVIDIA_API_KEY"])
    agent = ToolCallingAgent(tools=[], model=model, add_base_tools=False)
    t=time.time(); out = agent.run(PROMPT, max_steps=3); return True, {"output": str(out)[:800], "tempo_s": round(time.time()-t,1)}

def run_pydantic_ai():
    from pydantic_ai import Agent
    from pydantic import BaseModel
    from pydantic_ai.models.openai import OpenAIChatModel
    from pydantic_ai.providers.openai import OpenAIProvider
    class Resp(BaseModel):
        dias_para_natal: int; capital_franca: str; vogais_agentic: int; passos: list[str]
    model = OpenAIChatModel(MODEL, provider=OpenAIProvider(base_url=NVIDIA_BASE, api_key=os.environ["NVIDIA_API_KEY"]))
    agent = Agent(model=model, output_type=Resp, system_prompt="JSON only.")
    t=time.time(); r = agent.run_sync(PROMPT); return True, {"output": r.output.model_dump(), "tempo_s": round(time.time()-t,1)}

def run_langchain():
    from langchain_openai import ChatOpenAI
    from langchain_core.messages import HumanMessage
    llm = ChatOpenAI(model=MODEL, base_url=NVIDIA_BASE, api_key=os.environ["NVIDIA_API_KEY"], temperature=0)
    t=time.time(); m = llm.invoke([HumanMessage(content=PROMPT)]); return True, {"output": m.content[:800], "tempo_s": round(time.time()-t,1)}

def run_agno():
    from agno.agent import Agent
    from agno.models.openai import OpenAIChat
    agent = Agent(model=OpenAIChat(id=MODEL, api_key=os.environ["NVIDIA_API_KEY"], base_url=NVIDIA_BASE), markdown=False)
    t=time.time(); r = agent.run(PROMPT); return True, {"output": (r.content or "")[:800], "tempo_s": round(time.time()-t,1)}

def run_crewai():
    from crewai import Agent as CrewAgent, Task, Crew
    from crewai.llm import LLM
    llm = LLM(model="openai/"+MODEL, base_url=NVIDIA_BASE, api_key=os.environ["NVIDIA_API_KEY"], temperature=0)
    a = CrewAgent(role="Solver", goal="resolver", backstory="util", llm=llm, verbose=False)
    tk = Task(description=PROMPT, expected_output="JSON", agent=a)
    crew = Crew(agents=[a], tasks=[tk], verbose=False)
    t=time.time(); out = crew.kickoff(); return True, {"output": str(out)[:800], "tempo_s": round(time.time()-t,1)}

def run_autogen():
    from autogen_agentchat.agents import AssistantAgent
    from autogen_ext.models.openai import OpenAIChatCompletionClient
    import asyncio
    model = OpenAIChatCompletionClient(model=MODEL, base_url=NVIDIA_BASE, api_key=os.environ["NVIDIA_API_KEY"],
                                       model_info={"vision":False,"function_calling":True,"json_output":False,"family":"llama"})
    agent = AssistantAgent(name="solver", model_client=model, system_message="JSON only.")
    async def go():
        parts=[]
        async for m in agent.run_stream(task=PROMPT):
            if hasattr(m,"content"): parts.append(str(m.content))
        return "".join(parts)
    t=time.time(); out = asyncio.run(go()); return True, {"output": out[:800], "tempo_s": round(time.time()-t,1)}

if __name__ == "__main__":
    runners = {"smolagents": run_smolagents, "pydantic-ai": run_pydantic_ai, "langchain": run_langchain,
               "agno": run_agno, "crewai": run_crewai, "autogen": run_autogen}
    for name, fn in runners.items():
        try:
            ok, payload = timeout_guard(fn, 150)
            record(name, ok, payload)
        except Exception as e:
            record(name, False, {"erro": str(e), "trace": traceback.format_exc()[-500:]})
        print(name, "ok=", RESULTS[name]["ok"])
    json.dump(RESULTS, open("results.json","w"), ensure_ascii=False, indent=2)
    print("saved results.json")
