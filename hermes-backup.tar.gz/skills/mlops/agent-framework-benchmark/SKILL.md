---
name: agent-framework-benchmark
description: "Run a REAL (not theoretical) benchmark of open-source agentic-AI frameworks (smolagents, pydantic-ai, langchain, agno, crewai, autogen) OR a head-to-head MODEL comparison ('bolão das IAs') against one shared LLM backend. Covers validated OpenAI-compatible wiring per framework, a direct-urllib model harness, the NVIDIA API as a free working backend, a reusable harness, scoring, and ad-hoc verification."
version: 1.0.0
author: Hermes Agent
license: MIT
platforms: [linux, macos]
metadata:
  hermes:
    tags: [agents, benchmark, smolagents, pydantic-ai, langchain, agno, crewai, autogen, nvidia-api, openai-compatible]
    related_skills: [mlops/inference/serving-llms-vllm, github-auth]
---

# Agent Framework Benchmark (real execution)

Test agentic-AI frameworks by actually RUNNING them on a SHARED task + SHARED LLM backend, then scoring. This beat "theoretical analysis" — the user explicitly wanted real runs, not prose.

## When to use
- User asks to "test/compare/rate agentic AI frameworks" (smolagents, pydantic-ai, langchain, agno, crewai, autogen, MetaGPT, OpenHands...).
- Default to REAL execution over qualitative analysis unless the user opts for the cheap path. Real runs need an LLM backend (API key + credits).

## Backend: NVIDIA API (free, OpenAI-compatible) — validated working
- Env: `NVIDIA_API_KEY` (often in `~/.hermes/.env` as `NVIDIA_API_KEY=...`). Read the file in Python, never shell-`cat` a token into a URL.
- Endpoint: `https://integrate.api.nvidia.com/v1` (OpenAI-compatible: `/v1/chat/completions`, `/v1/models`).
- Model IDs (confirmed live 2026-07-13 via GET /v1/models):
  - WORKING & FREE: `meta/llama-3.1-8b-instruct` (fast ~1-9s, but weakest — miscalcs dates/vowels), `z-ai/glm-5.2` (PERFECT on the JSON bolão, ~15s), `deepseek-ai/deepseek-v4-flash` (PERFECT on JSON, ~43s) and `deepseek-ai/deepseek-v4-pro` (PERFECT on JSON, ~27s), `mistralai/mistral-small-4-119b-2603` (PERFECT on JSON + fastest ~2.2s — best cost/benefit), `qwen/qwen3.5-122b-a10b` (good on JSON, ~2.6s, missed 1 of 3).
  - BROKEN AT INFRA LEVEL (NOT model intelligence): `moonshotai/kimi-k2.6` → HTTP 404 (endpoint not servable / not GA under that id), `nvidia/llama-3.1-nemotron-nano-8b-v1` → read timeout 90s (too slow/overloaded). Do NOT record these as "nota 0" — mark status=erro_api_404 / erro_api_timeout so the report is honest.
  - NUANCE (learned this session): "PERFECT on the JSON bolão" does NOT imply "solves the escape room". GLM-5.2 and DeepSeek-v4-flash both scored 10/10 on the JSON task yet PATINED on Jogo do Cofre — they discovered the 3 digits + key but failed the final nav/action sequence (e.g. tried `digitar 319` while standing in the kitchen, not the escritório). JSON accuracy and multi-step agentic planning are different skills. Score escape-room runs by OUTCOME, and expect even "top" JSON models to loop or wander. The NVIDIA-hosted `z-ai/glm-5.2` behaves like a SMALL model on agentic planning despite its JSON strength.
- Model NOT on NVIDIA: `hy3` (Tencent/Hunyuan, this-chat's model) exists only via OpenRouter — needs OPENROUTER_API_KEY. If the user asks for it, offer OpenRouter wiring rather than NVIDIA.
- **2nd free backend: OPENROUTER (`:free` models).** Key `OPENROUTER_API_KEY` (often in `~/.hermes/.env`). Endpoint `https://openrouter.ai/api/v1/chat/completions` — OpenAI-compatible, same harness, just swap `API_URL`/`API_KEY`/`API_MODEL`. `GET /v1/models` lists ~345 models; filter id containing `:free` (or pricing 0/0) → ~26 free models incl. `tencent/hy3:free` (this-chat's model!), `meta-llama/llama-3.3-70b-instruct:free`, `openai/gpt-oss-120b:free`, `openai/gpt-oss-20b:free`, `google/gemma-4-26b-a4b-it:free`, `qwen/qwen3-next-80b-a3b-instruct:free`, `nvidia/nemotron-3-super-120b-a12b:free`. **CRITICAL QUOTA PITFALL:** the `:free` tier has a TINY daily cap — after a few calls you get `{"error":{"message":"Rate limit exceeded: free-models-per-day. Add 10 credits to..."}}`. So OpenRouter free is good for 1-2 test calls (e.g. validating `hy3:free` works) but NOT for running an agent that needs 25-70 calls. Some `:free` models also return `{"error":{"message":"Provider returned error"}}` intermittently (provider-side, not your key). To run a full agent on OpenRouter you need ~$10 credit. See `references/openrouter_free.md`.
- **LARGE NVIDIA MODELS STALL ON LATENCY (not 429).** `deepseek-ai/deepseek-v4-pro` and `microsoft/phi-4-mini-instruct` both responded fine to a single isolated call ("319") but then FROZE on LLM #2 of the agent loop for ~4.5 min with NO 429/503 in the log — the free tier simply goes very slow at peak. This is different from the flash's clean 503. If a model stalls this way, STOP and record `status="nao_concluido"` with `motivo="NVIDIA gratuita lenta (LLM #2 travada ~Xmin)"` — do NOT mark it a loss/derrota, and do NOT burn the whole session retrying. Retry later at a different hour. (Contrast: `deepseek-v4-flash` fails FAST with explicit 503 — that's `erro_api_503`.)
- ALWAYS re-list live before a run: `curl -s -H "Authorization: Bearer $KEY" https://integrate.api.nvidia.com/v1/models | python3 -c "import sys,json; [print(m['id']) for m in json.load(sys.stdin)['data'] if any(k in m['id'].lower() for k in ['glm','deepseek','qwen','kimi','mistral','nemotron','llama'])]"`. Catalog churns — IDs in this skill go stale.
- To list models: GET `/v1/models` with `Authorization: Bearer $KEY`.
- CRITICAL: the large 70B model timed out. Use `meta/llama-3.1-8b-instruct` for stable, fast benchmark runs. Model quality (not framework) is the main source of task errors with an 8B model.

## Per-framework OpenAI-compatible wiring (validated gotchas)
Each framework needs a slightly different incantation to point at a non-OpenAI base_url. All tested with `meta/llama-3.1-8b-instruct`.

- **smolagents**: use `OpenAIServerModel(model_id=..., api_base=NVIDIA_BASE, api_key=KEY)` (NOT `InferenceClientModel`, which rejects `api_base`). Prefer `ToolCallingAgent` over `CodeAgent` — CodeAgent with a small model loops for ~150s. Set `agent.run(prompt, max_steps=3)`.
- **pydantic-ai**: `OpenAIChatModel(MODEL, provider=OpenAIProvider(base_url=NVIDIA_BASE, api_key=KEY))` + `Agent(model=..., output_type=BaseModel)`. (NOT `Agent(model=..., api_base=...)` — rejected.)
- **langchain**: `ChatOpenAI(model=MODEL, base_url=NVIDIA_BASE, api_key=KEY, temperature=0)` — works first try.
- **agno**: `OpenAIChat(id=MODEL, api_key=KEY, base_url=NVIDIA_BASE)` — works first try.
- **crewai**: needs `pip install litellm`. Use `LLM(model="openai/<model_id>", base_url=NVIDIA_BASE, api_key=KEY)` — the bare model id is rejected.
- **autogen** (new API): `pip install autogen-agentchat autogen-ext`, then `OpenAIChatCompletionClient(model=MODEL, base_url=NVIDIA_BASE, api_key=KEY, model_info={"vision":False,"function_calling":True,"json_output":False,"family":"llama"})`. `model_info` is REQUIRED for non-OpenAI models. Iterate with `async for m in agent.run_stream(task=...)` — `run_stream` returns an async generator, do NOT `await` it.

## Model comparison — "bolão das IAs" (direct-urllib, no SDK)
When the user wants to compare MODELS (not frameworks) on a shared task, do NOT install six SDKs. The NVIDIA `/v1/chat/completions` endpoint is OpenAI-compatible, so hit it directly with `urllib` — one harness, any model, no per-library wiring.

- Load key from `~/.hermes/.env` in Python; set `BASE="https://integrate.api.nvidia.com/v1"`.
- One `chat/completions` POST per model, same `messages`/`temperature=0`/`max_tokens`. For GLM add `"response_format":{"type":"json_object"}` (and strip the `, "response_format": null` from the body when the model doesn't need it — build the dict, then `json.dumps(body).replace(', "response_format": null','')`).
- Parse robustly (models emit JSON in the wild): strip ```json fences, then `json.loads`; if that fails, `text[text.find('{'):text.rfind('}')+1]` slice and retry. Never trust raw string equals.
- Score: `nota = acertos/3 * 10` against deterministic ground truth (e.g. 165 dias, Paris, 3 vogais).
- `templates/bolao.py` — drop-in model-comparison runner: 8 free NVIDIA models, same shared TASK, `signal`-based 150s timeout per model, writes `bolao_resultados.json` incrementally (so a hang loses only one model), prints a ranked table at the end.
- Report infra failures honestly: a 404 / timeout means the ENDPOINT is broken, not the model's intelligence. Tag `status=erro_api_404|erro_api_timeout` and exclude from the scored ranking (note them separately).

## Reusable harness
- `templates/harness.py` — drop-in benchmark runner: loads NVIDIA key from `~/.hermes/.env`, defines one TASK, runs it through each framework's `run_*` fn, records `{ok, output, tempo_s}`, with a `signal`-based per-agent timeout guard (150s) so one stuck agent can't hang the whole run.
- `templates/bolao.py` — drop-in MODEL-comparison runner (direct urllib, 8 free NVIDIA models, incremental JSON, shared TASK). Use this for "bolão das IAs" / head-to-head model tests.
- `templates/agente_plano.py` — drop-in PLANNER agent for step-game servers (Jogo do Cofre): batches up to N actions per LLM call + 429 exponential backoff. Use INSTEAD of stock `agente.py` on the NVIDIA free tier (one-call-per-step triggers 429 storms). See the Escape-room section above.
- `scripts/consolidate.py <main.json> <extra1.json> [extra2.json ...]` — offline JSON merge that pulls ok=True entries from split-run files into the main results.json and asserts all frameworks end up ok.

## Method
1. Pick ONE task given identically to every agent (e.g. "days until Christmas from today + capital of France + count vowels in 'agentic', return JSON"). Include a deterministic ground truth to score against.
2. Give every agent the SAME model + backend.
3. Score each: Execution (did it run?), Parse (valid JSON out?), Accuracy (vs ground truth), Speed (seconds). Weighted example: 0.25*exec + 0.20*parse + 0.40*accuracy + 0.15*speed.
4. Report a ranked table + per-framework notes (setup pain, what it got right/wrong, where the error came from — model vs framework).

## Ad-hoc verification (no test suite)
After editing the harness, verify structurally without re-spending API calls:
- `py_compile` both files; import each module; assert each `run_*` fn is callable; assert `MODEL`/`NVIDIA_BASE` constants are set.
- Separately confirm saved `results.json`/`notas.json` are valid JSON and the ranking is reproducible from the parsing fn.
- State explicitly this is AD-HOC (integrity/reproducibility), NOT a clean re-run. Re-running all agents costs API time — offer it, don't assume.

## Escape-room / game-based agentic benchmark ("Jogo do Cofre")
Some "bolão das IAs" videos aren't JSON-QA — they're full escape rooms where the LLM must explore a world and act to win (ex: `inteligenciamilgrau/jogodocofre` — "Jogo do Cofre": open a safe by finding 3 digits hidden in rooms). This is a STRONGER agentic test than the JSON task above.

- The game repo ships a generic engine (`cofre.py`, Gymnasium-like `reset/step`) + `server.py` (Flask REST + MCP on port 5002) + `agente.py` (OpenAI-compatible LLM client). The harness is model-agnostic: point `API_URL`/`API_KEY`/`API_MODEL` in `.env` at ANY OpenAI-compatible endpoint (e.g. NVIDIA) and the stock agent plays. The stock `agente.py` is fine for local/Ollama; for the NVIDIA free tier ALWAYS use `templates/agente_plano.py` (planner + 429/503 backoff + empty-LLM fallback) instead — the one-call-per-step stock agent triggers 429 storms and stalls.
- **CRITICAL RATE-LIMIT PITFALL:** the stock `agente.py` does **one LLM call per environment step**. Against the NVIDIA free tier this triggers a storm of HTTP 429 (rate limit) — each game of ~50-200 steps becomes hours/days and the agent stalls. Fix BEFORE running:
  1. Add exponential backoff on 429/5xx in the LLM caller: `if r.status_code in (429,500,502,503): time.sleep(min(2**tent*5,60)); continue` (retry loop to 6). The NVIDIA free tier throws 503 (Service Unavailable) intermittently — a 429-only check lets those hang the agent for minutes. Also catch generic `requests.exceptions.HTTPError` and `Exception` with a short `time.sleep(5); continue` so a transient error becomes a retry, not a `None` that later breaks parsing.
  2. LLM-RETURNS-EMPTY pitfall: if the model emits no `ACAO:` lines (e.g. mid-run 503 swallowed by retry, or the model stops formatting), `parse_acoes` returns `[]` and a naive loop spams the same fallback forever or stalls. Guard it: on empty parse, inject a CONTEXT-AWARE fallback (if "chave" not yet in inventory → `["ir para quarto","abrir gaveta","pegar chave"]`; else → `["ir para escritorio","examinar quadro","usar chave em gaveta","abrir gaveta","digitar 319"]`), and print `[fallback] LLM vazia -> ...` so it's visible in logs. Never let empty → infinite no-op.
  3. Use a PLANNER agent instead of one-action-per-call: one LLM call returns a BATCH of up to N actions (`ACAO: ...` lines), then the loop executes each via separate `/step` calls. This cuts ~10x the LLM calls. Filter no-op actions (`olhar`, `ver`) and dedupe consecutive repeats so the agent doesn't spin.
  4. **SALA-AWARE FALLBACK (learned Jogo do Cofre):** small models frequently emit actions invalid from the CURRENT room (e.g. `ir para escritorio` while standing in the kitchen — the world only allows `ir para escritorio` from `sala`). Parse the room from the observation with `re.search(r"Voce esta na\s+([A-Za-zãÃéÉíÍóÓúÚçÇ ]+?)\.", obs)` and restrict the fallback to that room's valid exits (`acoes_validas_da_sala`). Without this, the agent loops on "Nao da pra ir" forever. See `templates/agente_plano.py` `sala_atual()` / `acoes_validas_da_sala()`.
  5. **END-GAME DETERMINISTIC PLANNER (the piece that won the room):** when the inventory shows all 3 digits + the key discovered, FORCE the final route, ignoring the LLM. Condition: `tem_3 = "canecas" in inv; tem_1 = "atras" in inv; tem_9 = ("9" in inv and "papel" in inv); tem_chave = "chave aqui" in inv`. If all four: if current room != "escritorio" → `["ir para sala","ir para escritorio"]`, else → `["usar chave em gaveta","abrir gaveta","digitar 319"]`. Small models (even GLM-5.2 / DeepSeek-v4-flash, both 10/10 on JSON) discover the digits + key but then FAIL the final nav sequence (try `digitar 319` in the wrong room). The forced planner converts "solved the puzzle" into an actual win. Without it, even strong-JSON models loop/wander and hit the 200-step cap.
  6. Space batches with a small `time.sleep(3)` between LLM calls.
  With these, the same NVIDIA models run 429-FREE and actually solve the room. See `references/cofre_escape_room.md` for the planner pattern and `templates/agente_plano.py` for a drop-in planner agent.
  - OpenRouter `:free` as a 2nd free backend: see `references/openrouter_free.md` (tiny daily cap, reasoning-model `max_tokens` note — probe-only, not for full agents).
- **REAL RESULT (2026-07-13, Fase 1, NVIDIA free tier, planner agent above):** of GLM-5.2, DeepSeek-v4-flash, Mistral-small-4, Qwen3.5-122b, llama-3.1-8b — ONLY **mistralai/mistral-small-4-119b-2603 WON** (95 steps, score +6, 25 LLM calls). Qwen3.5 and llama-3.1-8b hit the 200-step cap without opening the safe (wandered, malformed actions). GLM-5.2 stalled in EXPLORATION (patined revisiting rooms, never held all 3 digits + key simultaneously — stopped at 124 steps, no win); a follow-up run with the end-game planner still failed because the inventory condition never fired. DeepSeek-v4-flash hit 503 (Service Unavailable) on the NVIDIA side during its run and was not re-attempted. Takeaway: on this escape room, MODEL SIZE/RANK on JSON does NOT predict escape-room success — Mistral-small-4 (best JSON too) was the only solver; even GLM-5.2 (10/10 JSON) stalled. Expect most free NVIDIA models to NOT solve it without the end-game planner, AND even the planner only fires if the model actually collects all clues (weak explorers never trigger it).
- Score by OUTCOME, not JSON: `vitoria` (cofre aberto?), `passos` (fewer=better within the step cap), `chamadas_llm` (efficiency), `score` (game's own reward). Report which models solve it and how many steps. The puzzle difficulty is the point — a model that explores well but loops on `olhar` is a real signal, not a harness bug.
- Explore the repo's `src/jogos/` for the puzzle solution (e.g. `cofre_fase1.py` reveals code `319` = 3 mugs + digit behind quadro + digit on paper) ONLY to validate the harness — do not feed it to the model or the benchmark is void.
- If the YouTube video describing the challenge is IP-blocked (see Pitfalls), recover the challenge from the repo linked in the video description via the GitHub API (`api.github.com/users/<channel>/repos`) — search repo names/descriptions for the game (e.g. `jogodocofre`, `bolaodacopadasias`).

## Pitfalls
- `.format()` on a prompt containing `{...}` JSON breaks — use `prompt.replace("{hoje}", HOJE)`.
- Don't hand-`cat` tokens into shell URLs (security scan + log leak). Read from file in Python.
- Small models (8B) miscalc dates/vowels — attribute errors to the MODEL, not the framework, in the report.
- autogen `run_stream` is an async generator: `async for`, never `await`.

### Split-run / consolidation pitfalls
- STALE results.json AFTER SPLIT RUNS. If you run the harness in parts (e.g. run_bench.py, then run_extra.py for frameworks that failed and got fixed), the FIRST output file keeps the BROKEN intermediate result. Always consolidate before reporting: for each framework with ok:false, merge its corrected payload from the later run into the main results.json, then assert ALL frameworks are ok:true. In-session example: results.json showed autogen ok:false (model_info is required), but results_extra.json had autogen succeeding (165 dias). Use scripts/consolidate.py <main.json> <extra1.json> [extra2.json ...].
- execute_code PYTHON IS NOT THE PROJECT VENV. The execute_code sandbox interpreter often LACKS the benchmark packages (autogen_ext, smolagents, crewai, agno). Run import/verification checks via the project venv python directly through terminal, e.g. /home/codespace/.python/current/bin/python3 <verify>.py — NOT the execute_code sys.executable. A 'No module named autogen_ext' raised inside execute_code is a FALSE NEGATIVE, not a real break.
- inspect.signature LIES FOR AUTOGEN. OpenAIChatCompletionClient.__init__ absorbs model_info via **kwargs, so inspect.signature(...) will not list it. Verify the fix by constructing the client:
  - Caso A (sem model_info) raises ValueError: model_info is required when model name is not a valid OpenAI model (proves the bug existed).
  - Caso B (com model_info={'vision':False,'function_calling':True,'json_output':False,'family':'llama'}) constructs without that error (proves the fix). Any other error is just network/auth from the dummy key.
- AutoGen model_info NOW WARNS. The 4-field dict triggers UserWarning: Missing required field 'structured_output' in ModelInfo. This field will be required in a future version. Harmless today; add 'structured_output':False proactively for clean output.
- NVIDIA MODEL IDs GO STALE. `kimi-k2.6` returned 404 and `nemotron-nano-8b-v1` timed out under the same creds that served glm/deepseek/mistral fine — catalog churn, not a code bug. ALWAYS re-list `/v1/models` before a run; never hard-trust the IDs in this skill.
- RECORD INFRA FAILURES AS INFRA, not intelligence. A 404 or 90s timeout means the endpoint is broken/missing — flag `status=erro_api_404|erro_api_timeout` and keep the model OUT of the scored ranking. Demoting it to "nota 0" is a dishonest result.
- GLM 5.2 wants `response_format={"type":"json_object"}`; build the request body as a dict, add the field conditionally, then `json.dumps(body).replace(', "response_format": null','')` so non-GLM models don't get a stray null key.
- WRITE RESULTS INCREMENTALLY in long multi-model runs (append each model's result and dump `results.json` inside the loop). A 150s SIGALRM on one model would otherwise lose all prior results.
- YouTube transcripts are BLOCKED from cloud IPs (`IPBlocked` on youtube-transcript-api AND on page fetches). Don't burn turns retrying — tell the user the IP is blocked and ask them to paste the transcript/text if they need a faithful replica.
- RUN MODELS ONE AT A TIME on the NVIDIA free tier. Even with the planner agent (step 3), concurrent agents from the same API key multiply the 429/503 rate-limit pressure and stall both. Queue them (a small orchestrator that runs model N only after model N-1 finishes) instead of `background=true` x5. If the user gives a model PREFERENCE ORDER (e.g. "try GLM, if it fails don't try DeepSeek"), honor it EXACTLY: test the preferred model, and if it loses, STOP — do not silently run the excluded model. Record its result as the final word for that model and note the exclusion in the report.
- DISTINGUISH "stalled in exploration" from "failed the final nav". A model can reach the step cap without ever collecting all clues (weak explorer) OR collect all clues but loop on the wrong-room action. The end-game planner (step 5) only fires in the second case. If a model loses but its inventory never held all 3 digits + key, the bottleneck is EXPLORATION, not navigation — the planner won't save it. Report which.
- RECORD LATENCY-STALLS AS `nao_concluido`, NOT derrota. When a model freezes on a loop LLM call for minutes with no 429/503 (large NVIDIA models at peak — e.g. deepseek-v4-pro, phi-4-mini), stop the run, write the result JSON with `vitoria:false, status:"nao_concluido", motivo:"NVIDIA gratuita lenta (LLM #2 travada ~Xmin)"` and `passos:null`. This is an INFRA stall, not a model failure — never fold it into the scored "lost" column. Retry later when the backend is less loaded. (See `references/openrouter_free.md` for the OpenRouter-free daily-cap variant of the same "don't call it a loss" rule.)
