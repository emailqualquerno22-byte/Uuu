# Per-framework wiring — exact traps + fixes (validated 2026-07, NVIDIA backend)

All use backend `https://integrate.api.nvidia.com/v1`, model `meta/llama-3.1-8b-instruct`, key from `~/.hermes/.env` (`NVIDIA_API_KEY`).

## smolagents
- TRAP: `InferenceClient.chat_completion() got an unexpected keyword argument 'api_base'`
- FIX: `from smolagents import ToolCallingAgent, OpenAIServerModel`
  `model = OpenAIServerModel(model_id=MODEL, api_base=NVIDIA_BASE, api_key=KEY)`
  `agent = ToolCallingAgent(tools=[], model=model, add_base_tools=False)`
  `agent.run(PROMPT, max_steps=3)`
- NOTE: `CodeAgent` with 8B model looped ~149s. Use `ToolCallingAgent`.

## pydantic-ai
- TRAP: `Agent.__init__() got an unexpected keyword argument 'api_base'`
- FIX:
  `from pydantic_ai.models.openai import OpenAIChatModel`
  `from pydantic_ai.providers.openai import OpenAIProvider`
  `model = OpenAIChatModel(MODEL, provider=OpenAIProvider(base_url=NVIDIA_BASE, api_key=KEY))`
  `agent = Agent(model=model, output_type=Resp, system_prompt="...")`

## langchain
- Works first try: `from langchain_openai import ChatOpenAI`
  `llm = ChatOpenAI(model=MODEL, base_url=NVIDIA_BASE, api_key=KEY, temperature=0)`
  `llm.invoke([HumanMessage(content=PROMPT)])`

## agno
- Works first try: `from agno.agent import Agent; from agno.models.openai import OpenAIChat`
  `agent = Agent(model=OpenAIChat(id=MODEL, api_key=KEY, base_url=NVIDIA_BASE), markdown=False)`
  `agent.run(PROMPT)`

## crewai
- TRAP: `Unable to initialize LLM with model 'meta/llama-3.1-8b-instruct' ... LiteLLM fallback not installed`
- FIX: `pip install litellm`; use `LLM(model="openai/meta/llama-3.1-8b-instruct", base_url=NVIDIA_BASE, api_key=KEY)`
  (bare model id rejected; needs `openai/` prefix for litellm).

## autogen (new agentchat API)
- TRAP 1: `No module named 'autogen_ext'` -> `pip install autogen-agentchat autogen-ext`
- TRAP 2: `model_info is required when model name is not a valid OpenAI model` ->
  pass `model_info={"vision":False,"function_calling":True,"json_output":False,"family":"llama"}`
- TRAP 3: `object async_generator can't be used in 'await' expression` ->
  `async for m in agent.run_stream(task=PROMPT):` (it's an async generator, NOT awaitable)
- Working: `from autogen_agentchat.agents import AssistantAgent`
  `from autogen_ext.models.openai import OpenAIChatCompletionClient`
  `model = OpenAIChatCompletionClient(model=MODEL, base_url=NVIDIA_BASE, api_key=KEY, model_info={...})`
  `agent = AssistantAgent(name="solver", model_client=model, system_message="...")`

## NVIDIA model ID sanity (2026-07)
- OK fast: `meta/llama-3.1-8b-instruct`
- SLOW/timeout: `meta/llama-3.3-70b-instruct` (60s read timeout)
- 404 wrong IDs tried: `nvidia/llama-3.1-nemotron-70b-instruct`, `mistralai/mistral-7b-instruct-v0.3`, `google/gemma-2-9b-it`
