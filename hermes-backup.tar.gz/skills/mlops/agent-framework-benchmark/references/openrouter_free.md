# OpenRouter `:free` models — 2nd free backend for the bolão

Endpoint: `https://openrouter.ai/api/v1/chat/completions` (OpenAI-compatible — same harness as NVIDIA, just swap `API_URL`/`API_KEY`/`API_MODEL`).
Key: `OPENROUTER_API_KEY` (in `~/.hermes/.env`).

## How to find the free models
```python
import urllib.request, json
KEY = open("/home/codespace/.hermes/.env").read().split("OPENROUTER_API_KEY=")[1].split("\n")[0].strip().strip('"')
req = urllib.request.Request("https://openrouter.ai/api/v1/models", headers={"Authorization": f"Bearer {KEY}"})
d = json.load(urllib.request.urlopen(req, timeout=20))
ms = d.get("data", [])
free = [m["id"] for m in ms if ":free" in m["id"].lower()
        or (m.get("pricing", {}).get("prompt", "0") == "0"
            and m.get("pricing", {}).get("completion", "0") == "0")]
# ~26 free models total
```
List observed 2026-07-13 (subset, all OpenAI-compatible):
- `tencent/hy3:free` — **this-chat's model**; responds fine (but it is a REASONING model — see below)
- `meta-llama/llama-3.3-70b-instruct:free`
- `openai/gpt-oss-120b:free`, `openai/gpt-oss-20b:free`
- `google/gemma-4-26b-a4b-it:free`, `google/gemma-4-31b-it:free`
- `qwen/qwen3-next-80b-a3b-instruct:free`
- `nvidia/nemotron-3-super-120b-a12b:free`, `nvidia/nemotron-3-nano-30b-a3b:free`
- `meta-llama/llama-3.2-3b-instruct:free`, `liquid/lfm-2.5-1.2b-instruct:free`, `cognitivecomputations/dolphin-mistral-24b-venice-edition:free`

## CRITICAL: daily free-tier cap
After a handful of calls you get:
```json
{"error":{"message":"Rate limit exceeded: free-models-per-day. Add 10 credits to ..."}}
```
So `:free` is only good for **1-2 probe calls** (e.g. "does `hy3:free` answer?"). It CANNOT run a full agent (which needs 25-70 calls). To run a real agent on OpenRouter you need ~$10 of credit (then use the non-`:free` model ids or just pay per token).

Some `:free` ids also intermittently return `{"error":{"message":"Provider returned error"}}` — that's provider-side unavailability, NOT your key. Retry later / pick another free id.

## Reasoning models need bigger max_tokens
`hy3:free`, `gpt-oss-*`, `nemotron-*-omni` are REASONING models: they spend tokens in a `reasoning` field and may return `message.content == null` if `max_tokens` is too small (the budget got eaten by reasoning). Fix in the harness: set `max_tokens` generously (e.g. 800) and read `message.content` (ignore `reasoning`). The stock `agente_plano.py` planner works as-is once max_tokens is raised.

## When to use OpenRouter-free vs NVIDIA
- **NVIDIA free**: stable enough for full agent runs (with the planner agent + 429/503 backoff). Preferred for the Jogo do Cofre / bolão.
- **OpenRouter `:free`**: only for a quick probe that a specific model (e.g. `hy3:free`) is reachable, or when NVIDIA is fully down. Not for multi-call agents without credit.
