# Jogo do Cofre — Escape-room agentic benchmark (NVIDIA free tier)

Source repo: `github.com/inteligenciamilgrau/jogodocofre` ("Jogo do Cofre").
A real challenge behind some "bolão das IAs" YouTube videos — the LLM is dropped
in a house with no instructions and must open a safe by exploring (read notes,
find digits behind frames, unlock drawers, assemble the code).

## Why the stock agent stalls on NVIDIA free tier
`src/agente.py` calls the LLM **once per environment step** (`/step`). The NVIDIA
free catalog has a low RPM, so a ~50-200 step game fires hundreds of calls →
constant `HTTP 429` → the game never finishes. Observed: GLM-5.2 hit 429 on 8 of
its first 14 calls and was still on turn 3 after 9 minutes.

## The fix (validated this session)
Two changes, both required:

### 1. Exponential backoff on 429 (in the LLM caller)
```python
for tent in range(1, 6):
    r = requests.post(API_URL, headers=headers, json=payload, timeout=60)
    if r.status_code == 429:
        time.sleep(min(2 ** tent * 5, 60)); continue
    r.raise_for_status()
    return r.json()["choices"][0]["message"]["content"].strip()
```

### 2. Planner agent — many actions per LLM call
Instead of `ACAO:` → one `/step`, the LLM returns a BATCH (up to N, e.g. 6):
```
PENSAMENTO: [brief]
ACAO: ir para cozinha
ACAO: abrir armario
ACAO: examinar armario
```
The loop executes each via its own `/step`, then calls the LLM again. This cuts
~10x the calls. Add guards:
- Filter no-op actions: `INUTEIS = {"olhar","ver","observar","look"}`.
- Dedupe consecutive repeats (`if a != ultima_acao`).
- `time.sleep(3)` between LLM batches.

Result: DeepSeek-v4-flash ran 429-FREE, explored correctly (found 3 mugs = digit 3,
picked up the key at step 99), and progressed to ~step 130 of 200 without stalling.

## Wiring NVIDIA as the backend
`.env` (server + agent read it via python-dotenv):
```
API_URL=https://integrate.api.nvidia.com/v1/chat/completions
API_KEY=<NVIDIA_API_KEY from ~/.hermes/.env>
API_MODEL=z-ai/glm-5.2        # or deepseek-ai/deepseek-v4-flash, etc.
COFRE_SERVER=http://localhost:5002
COFRE_JOGO=cofre_fase1        # or cofre_fase2 (harder: digits need reorder +1)
COFRE_MODO=livre
```
Run: `python3 src/server.py` (background), then the planner agent.

## Server endpoints used
- `POST /reset`  body `{"model":<id>,"jogo":<id>}` → `{obs, run_id, success}`
- `POST /step`   body `{"action":<str>}` → `{obs, reward, steps, score, terminated, truncated}`
- `GET  /jogos`  lists discovered phases (`cofre_fase1`, `cofre_fase2`)
State is global per server process (one game at a time) — run models SEQUENTIALLY,
not in parallel, or they'll share/reset the same game.

## Scoring
`vitoria` (terminated with cofre open), `passos` (fewer better), `chamadas_llm`
(efficiency), `score` (game reward = -1/step +100 win). A model that loops on
`olhar` or repeats failed moves is a real capability signal — report it, don't
paper over it. Save one `resultado_<model>_<fase>.json` per run.

## Phases
- `cofre_fase1` (easy): code 319 — 3 mugs in kitchen armário, 1 behind escritório
  quadro, 9 on paper in locked escritório gaveta (needs key from quarto).
- `cofre_fase2` (hard): code 835 — decoy numbers everywhere; digits must be
  reordered and +1 each.

## Pitfall: don't read the solution into the prompt
`src/jogos/cofre_fase1.py` literally contains `codigo: "319"` and the room layout.
Use it ONLY to validate the harness (confirm the engine wins via `python src/cofre.py`).
Never pass solution text to the model — that voids the benchmark.
