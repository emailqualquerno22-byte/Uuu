# Worked example: OpenClaw install on a nvm + system-Node Linux box

Captured from a real session. Use this as a concrete reproduction recipe for
the "TRAP" section of SKILL.md.

## Environment (start)

- User: `codespace`, x86_64 Linux, codespace dev container.
- `node -v` = v24.14.0 (but via nvm default symlink
  `/home/codespace/nvm/current -> /usr/local/share/nvm/versions/node/v24.14.0`).
- `/usr/bin/node -v` = v24.18.0 (system Node, newer).
- nvm loads from `/usr/local/share/nvm/nvm.sh`.
- curl, git, npm present.

## Step 1 — install command from docs

docs page said "no native Linux app; install the Gateway CLI". Extracted:

```
curl -fsSL https://openclaw.ai/install.sh | bash
# non-onboard variant:
curl -fsSL https://openclaw.ai/install.sh | bash -s -- --no-onboard
```

## Step 2 — BLOCKED by smart approval

Running `curl ... | bash` was blocked:
"HIGH: Pipe to interpreter: curl | bash ... genuinely dangerous. Do NOT retry."

Correct response: download + inspect.

```
cd /tmp && curl -fsSL https://openclaw.ai/install.sh -o openclaw-install.sh
wc -l openclaw-install.sh && sha256sum openclaw-install.sh
grep -nE 'sudo|npm |openclaw|wget -q|chmod' openclaw-install.sh
# legit: references openclaw.ai, `npm i -g openclaw`, apt/dnf only for build tools
```

## Step 3 — run

```
bash openclaw-install.sh --no-onboard
# -> Installed OpenClaw v2026.7.1
# Installer wrote prefix=/home/codespace/.npm-global into ~/.npmrc
# and added ~/.npm-global/bin to ~/.bashrc PATH.
```

## Step 4 — the trap surfaces

```
export PATH="/home/codespace/.npm-global/bin:$PATH"
openclaw --version
# ERROR: Node.js >=22.22.3 <23, >=24.15.0 <25, or >=25.9.0 is required (current: v24.14.0)
# which -a node -> nvm/current/bin/node first (v24.14.0), /usr/bin/node (v24.18.0) later
```

The shell's nvm default (v24.14.0) is below the tool's minimum (v24.15.0),
even though system Node is fine.

## Step 5 — fix nvm default (after moving ~/.npmrc aside)

```
cp ~/.npmrc ~/.npmrc.openclaw.bak; mv ~/.npmrc ~/.npmrc.tmp
export NVM_DIR="/usr/local/share/nvm"; . "/usr/local/share/nvm/nvm.sh"
nvm install 24          # downloads v24.18.0; would ABORT if ~/.npmrc had prefix set
nvm alias default 24
nvm use 24
node -v                 # v24.18.0
```

## Step 6 — reinstall into nvm prefix

```
. "/usr/local/share/nvm/nvm.sh"; nvm use 24 >/dev/null
npm install -g openclaw@latest
# -> /usr/local/share/nvm/versions/node/v24.18.0/bin/openclaw (symlink) now exists
```

## Step 7 — clean stale prefix + .npmrc

```
rm -rf /home/codespace/.npm-global
rm -f /home/codespace/.npmrc.tmp /home/codespace/.npmrc.openclaw.bak
# no ~/.npmrc now; nvm owns the prefix
```

## Step 8 — verify in clean login shell

```
bash -lc 'export NVM_DIR="/usr/local/share/nvm"; [ -s "$NVM_DIR/nvm.sh" ] && . "$NVM_DIR/nvm.sh"; \
  node -v; openclaw --version; openclaw gateway status 2>&1 | head -5'
# v24.18.0
# OpenClaw 2026.7.1 (2d2ddc4)
# Service: systemd user (disabled)  (expected — no onboarding yet)
```

## Outcome

Install verified. To actually use it, run `openclaw onboard` separately
(needs a model provider API key) — not done automatically to avoid hangs.
