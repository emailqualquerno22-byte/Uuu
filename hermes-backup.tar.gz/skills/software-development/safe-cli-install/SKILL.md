---
name: safe-cli-install
description: Install a third-party developer CLI that ships an install script (curl|bash, npm -g, etc.) into a Linux environment that uses nvm and/or system Node. Covers the smart-approval block on `curl | bash`, the download-then-inspect-then-run pattern, verifying the script is legitimate, and — the easy-to-miss trap — resolving nvm-vs-system-Node version conflicts and the `~/.npmrc` `prefix=` conflict that makes the binary land in a non-default prefix or under an older Node. Use whenever the user pastes an install URL for a CLI/app (OpenClaw, CLI tools, etc.) and you must install it without blindly piping to a shell.
---

# Safe CLI install (script-based, Node/npm-global)

Use this when a user says "install this" and gives a docs/install URL for a
command-line app or developer tool. The naive `curl -fsSL <url> | bash` will
usually be **blocked by the smart-approval security scan** in this environment
(HIGH: "Pipe to interpreter: curl | bash"), so never retry it blindly. Follow
the safe pattern below.

## 1. Get the real install command

The install URL is usually docs, not the script. Open the page (browser or
`web_extract`) and extract the actual command. Common shapes:

- `curl -fsSL https://example.com/install.sh | bash`
- `curl -fsSL https://example.com/install-cli.sh | bash`   (local prefix variant)
- `npm install -g <pkg>@latest`
- `iwr -useb https://example.com/install.ps1 | iex`        (Windows/PowerShell)

If the page has multiple variants (onboard vs `--no-onboard`, npm vs git),
prefer the **non-onboarding** one so the run does not hang on interactive
prompts for API keys. You can run onboarding later, separately.

## 2. Download, then inspect BEFORE running

Replace the pipe-to-shell with download + read:

```bash
cd /tmp && curl -fsSL <script-url> -o install.sh
wc -l install.sh && sha256sum install.sh
```

Then verify legitimacy. Read the header and search for the dangerous tokens:

```bash
grep -nE 'sudo|eval |npm |openclaw|wget -q|chmod|bash -c' install.sh
```

A legitimate vendor installer will: reference its own domain, use `npm i -g
<pkg>`, maybe `sudo` only for system package installs (apt/dnf/pacman), and
write to a known prefix. If you see `curl ... | bash` nested, obfuscated
base64, or `eval` of downloaded content, STOP and ask the user.

## 3. Run it

```bash
bash install.sh --no-onboard     # or the variant flags you picked
```

## 4. THE TRAP: Node version + npm prefix conflict (nvm environments)

This is the part that wastes time. Many installers require a Node version
newer than what `nvm`'s default symlink points to, even when a newer Node is
installed system-wide. Symptoms:

- Install "succeeds" but the tool errors: `Node.js >=X is required (current: vY)`
- `which node` from your interactive shell shows the nvm default (e.g.
  `/home/<user>/nvm/current/bin/node` = v24.14.0) while `/usr/bin/node` is
  newer (v24.18.0). nvm shadows PATH, so the tool picks the older one.

### 4a. Diagnose

```bash
node -v; which -a node; /usr/bin/node -v
nvm ls
```

### 4b. Fix the Node version under nvm

The installer may have written `prefix=<path>` into `~/.npmrc` to make npm
install user-local. **nvm refuses to `nvm install`/`nvm use` while a
`prefix`/`globalconfig` setting is in `~/.npmrc`** ("incompatible with nvm").

```bash
# back up and move the conflicting .npmrc aside
cp ~/.npmrc ~/.npmrc.openclaw.bak; mv ~/.npmrc ~/.npmrc.tmp
export NVM_DIR="/usr/local/share/nvm"; . "/usr/local/share/nvm/nvm.sh"
nvm install 24            # or whatever major the tool needs
nvm alias default 24
nvm use 24
node -v                   # now the required version
```

### 4c. Reinstall the package into the nvm-managed prefix

If the first `npm i -g` landed in the `~/.npm-global` (or other) prefix set by
the installer's `.npmrc`, it is now off-path relative to nvm. Reinstall under
nvm so the bin sits in the nvm bin dir:

```bash
. "/usr/local/share/nvm/nvm.sh"; nvm use 24 >/dev/null
npm install -g <pkg>@latest
ls -la "$(dirname "$(nvm which 24)")/<pkg>"   # should exist as a symlink
```

### 4d. Clean up the stale prefix

Remove the orphaned installer-created prefix so future runs don't split:

```bash
rm -rf ~/.npm-global
rm -f ~/.npmrc.tmp ~/.npmrc.openclaw.bak   # keep .npmrc absent; nvm owns prefix
```

## 5. Verify in a CLEAN login shell

Don't trust your current shell's PATH. Source nvm in a fresh login shell:

```bash
bash -lc 'export NVM_DIR="/usr/local/share/nvm"; [ -s "$NVM_DIR/nvm.sh" ] && . "$NVM_DIR/nvm.sh"; node -v; <pkg> --version; <pkg> doctor 2>&1 | head'
```

If `<pkg> --version` prints a version (not a Node-error), the install is good.

## Pitfalls

- **Never re-run a blocked `curl | bash`** — the smart-approval block is a
  real guard, not a transient failure. Download + inspect instead.
- **Don't leave the installer's `prefix=` in `~/.npmrc`** if nvm is in play —
  it makes every future `nvm install` bail with "incompatible with nvm".
- **System Node may satisfy the tool but your shell won't see it** because nvm
  prepends its own bin. Fix the nvm default, don't fight PATH manually.
- **`--no-onboard` / `--no-onboard`** prevents hanging on API-key prompts;
  run onboarding separately only if the user supplies a key.
- Some installers auto-edit `~/.bashrc` to add the npm global bin to PATH —
  that line is harmless once the prefix is cleaned up, but prefer the nvm bin
  being first.

## References

See `references/node-nvm-prefix-conflict.md` for a full worked transcript
(OpenClaw install: nvm default v24.14.0 vs required v24.15.0, system v24.18.0,
`~/.npmrc` prefix conflict, reinstall into nvm prefix, clean-shell verify).
